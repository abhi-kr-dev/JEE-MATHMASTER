import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { BookOpen, CheckCircle, Clock, Target, TrendingUp, Award, Calendar, Lock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';

const ProgressPage = () => {
  const { user } = useAuth();
  const [selectedTimeframe, setSelectedTimeframe] = useState('week');

  useEffect(() => {
    if (!user) {
      window.location.href = '/login';
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center glass-effect p-12 rounded-xl max-w-md">
          <Lock className="w-16 h-16 text-gray-400 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-white mb-4">Login Required</h2>
          <p className="text-gray-300 mb-6">
            Please login to access your progress tracking and study analytics.
          </p>
          <div className="space-y-3">
            <Button asChild className="w-full">
              <a href="/login">Login</a>
            </Button>
            <Button asChild variant="outline" className="w-full">
              <a href="/register">Create Account</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const chapterProgress = [
    { 
      chapter: 'Algebra', 
      totalTopics: 8, 
      completedTopics: 6, 
      progress: 75,
      timeSpent: 24,
      lastStudied: '2025-06-24',
      topics: [
        { name: 'Quadratic Equations', completed: true, accuracy: 85 },
        { name: 'Complex Numbers', completed: true, accuracy: 92 },
        { name: 'Sequences & Series', completed: true, accuracy: 78 },
        { name: 'Permutations & Combinations', completed: true, accuracy: 88 },
        { name: 'Binomial Theorem', completed: true, accuracy: 82 },
        { name: 'Matrices & Determinants', completed: true, accuracy: 76 },
        { name: 'Probability', completed: false, accuracy: 0 },
        { name: 'Mathematical Induction', completed: false, accuracy: 0 }
      ]
    },
    { 
      chapter: 'Calculus', 
      totalTopics: 6, 
      completedTopics: 4, 
      progress: 67,
      timeSpent: 18,
      lastStudied: '2025-06-23',
      topics: [
        { name: 'Limits', completed: true, accuracy: 90 },
        { name: 'Derivatives', completed: true, accuracy: 87 },
        { name: 'Applications of Derivatives', completed: true, accuracy: 83 },
        { name: 'Integrals', completed: true, accuracy: 79 },
        { name: 'Applications of Integrals', completed: false, accuracy: 0 },
        { name: 'Differential Equations', completed: false, accuracy: 0 }
      ]
    },
    { 
      chapter: 'Coordinate Geometry', 
      totalTopics: 5, 
      completedTopics: 3, 
      progress: 60,
      timeSpent: 15,
      lastStudied: '2025-06-22',
      topics: [
        { name: 'Straight Lines', completed: true, accuracy: 88 },
        { name: 'Circles', completed: true, accuracy: 85 },
        { name: 'Parabola', completed: true, accuracy: 82 },
        { name: 'Ellipse', completed: false, accuracy: 0 },
        { name: 'Hyperbola', completed: false, accuracy: 0 }
      ]
    },
    { 
      chapter: 'Trigonometry', 
      totalTopics: 4, 
      completedTopics: 3, 
      progress: 75,
      timeSpent: 12,
      lastStudied: '2025-06-21',
      topics: [
        { name: 'Basic Trigonometry', completed: true, accuracy: 91 },
        { name: 'Trigonometric Equations', completed: true, accuracy: 86 },
        { name: 'Inverse Trigonometry', completed: true, accuracy: 84 },
        { name: 'Properties of Triangles', completed: false, accuracy: 0 }
      ]
    },
    { 
      chapter: 'Vectors & 3D Geometry', 
      totalTopics: 4, 
      completedTopics: 2, 
      progress: 50,
      timeSpent: 8,
      lastStudied: '2025-06-20',
      topics: [
        { name: 'Vector Algebra', completed: true, accuracy: 89 },
        { name: 'Scalar Triple Product', completed: true, accuracy: 87 },
        { name: 'Vector Triple Product', completed: false, accuracy: 0 },
        { name: '3D Lines & Planes', completed: false, accuracy: 0 }
      ]
    }
  ];

  const weeklyGoals = [
    { goal: 'Complete 5 quiz sessions', current: 3, target: 5, completed: false },
    { goal: 'Study 3 new topics', current: 2, target: 3, completed: false },
    { goal: 'Achieve 80% average accuracy', current: 85, target: 80, completed: true },
    { goal: 'Spend 15 hours studying', current: 12, target: 15, completed: false }
  ];

  const studyStreak = {
    current: 15,
    longest: 23,
    thisWeek: 6
  };

  const getProgressColor = (progress) => {
    if (progress >= 80) return 'from-green-500 to-emerald-600';
    if (progress >= 60) return 'from-yellow-500 to-orange-600';
    return 'from-red-500 to-pink-600';
  };

  const getAccuracyColor = (accuracy) => {
    if (accuracy >= 85) return 'text-green-400';
    if (accuracy >= 75) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <>
      <Helmet>
        <title>Chapter Progress Tracker - MathSparsh</title>
        <meta name="description" content="Track your JEE mathematics preparation progress chapter-wise. Monitor completion rates, accuracy, and study goals." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Progress Tracker
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Monitor your chapter-wise progress and achieve your study goals
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Award className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{studyStreak.current}</div>
              <div className="text-gray-300 text-sm">Day Streak</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Target className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">
                {chapterProgress.reduce((acc, ch) => acc + ch.completedTopics, 0)}
              </div>
              <div className="text-gray-300 text-sm">Topics Completed</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Clock className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">
                {chapterProgress.reduce((acc, ch) => acc + ch.timeSpent, 0)}h
              </div>
              <div className="text-gray-300 text-sm">Total Study Time</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <TrendingUp className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">
                {Math.round(chapterProgress.reduce((acc, ch) => acc + ch.progress, 0) / chapterProgress.length)}%
              </div>
              <div className="text-gray-300 text-sm">Overall Progress</div>
            </motion.div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="lg:col-span-2 glass-effect p-6 rounded-xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-white">Chapter Progress</h2>
                <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="all">All Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-6">
                {chapterProgress.map((chapter, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-black/20 p-6 rounded-lg"
                  >
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-white">{chapter.chapter}</h3>
                        <p className="text-gray-400 text-sm">
                          {chapter.completedTopics}/{chapter.totalTopics} topics completed • 
                          {chapter.timeSpent}h studied • 
                          Last studied: {new Date(chapter.lastStudied).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-white">{chapter.progress}%</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="w-full bg-gray-700 rounded-full h-3">
                        <div 
                          className={`h-3 rounded-full bg-gradient-to-r ${getProgressColor(chapter.progress)}`}
                          style={{ width: `${chapter.progress}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-2">
                      {chapter.topics.map((topic, topicIndex) => (
                        <div key={topicIndex} className="flex items-center justify-between p-2 bg-black/20 rounded">
                          <div className="flex items-center space-x-2">
                            {topic.completed ? (
                              <CheckCircle className="w-4 h-4 text-green-400" />
                            ) : (
                              <div className="w-4 h-4 border-2 border-gray-500 rounded-full"></div>
                            )}
                            <span className={`text-sm ${topic.completed ? 'text-white' : 'text-gray-400'}`}>
                              {topic.name}
                            </span>
                          </div>
                          {topic.completed && (
                            <span className={`text-xs font-medium ${getAccuracyColor(topic.accuracy)}`}>
                              {topic.accuracy}%
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-6"
            >
              <div className="glass-effect p-6 rounded-xl">
                <h3 className="text-xl font-bold text-white mb-4">Weekly Goals</h3>
                <div className="space-y-4">
                  {weeklyGoals.map((goal, index) => (
                    <div key={index} className="bg-black/20 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-white text-sm">{goal.goal}</span>
                        {goal.completed && <CheckCircle className="w-4 h-4 text-green-400" />}
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-400">
                        <span>{goal.current}/{goal.target}</span>
                        <span>{Math.round((goal.current / goal.target) * 100)}%</span>
                      </div>
                      <Progress 
                        value={(goal.current / goal.target) * 100} 
                        className="h-2 mt-2" 
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-effect p-6 rounded-xl">
                <h3 className="text-xl font-bold text-white mb-4">Study Streak</h3>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold gradient-text mb-2">{studyStreak.current}</div>
                    <div className="text-gray-300 text-sm">Current Streak</div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-white">{studyStreak.longest}</div>
                      <div className="text-gray-400 text-xs">Longest</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-white">{studyStreak.thisWeek}</div>
                      <div className="text-gray-400 text-xs">This Week</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass-effect p-6 rounded-xl">
                <h3 className="text-xl font-bold text-white mb-4">Quick Actions</h3>
                <div className="space-y-3">
                  <Button className="w-full" asChild>
                    <a href="/quiz">Continue Learning</a>
                  </Button>
                  <Button variant="outline" className="w-full" asChild>
                    <a href="/mock-test">Take Mock Test</a>
                  </Button>
                  <Button variant="outline" className="w-full" asChild>
                    <a href="/analytics">View Analytics</a>
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProgressPage;