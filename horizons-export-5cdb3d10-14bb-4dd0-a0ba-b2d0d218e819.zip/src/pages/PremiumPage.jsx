
import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Crown, Download, BookOpen, Target, BarChart3, Users, Zap, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';
import { usePayment } from '@/hooks/usePayment';
import PremiumPlans from '@/components/premium/PremiumPlans';
import PremiumFeatures from '@/components/premium/PremiumFeatures';

const PremiumPage = () => {
  const { user, upgradeToPremium } = useAuth();
  const { isProcessing, handleUpgrade } = usePayment(user, upgradeToPremium);

  const premiumBenefits = [
    {
      icon: Download,
      title: 'Unlimited PDF Downloads',
      description: 'Download question sets, solutions, and formula sheets for offline study'
    },
    {
      icon: BookOpen,
      title: 'Complete Question Bank',
      description: 'Access to 15,000+ carefully curated JEE questions across all topics'
    },
    {
      icon: Target,
      title: 'Unlimited Mock Tests',
      description: 'Take as many mock tests as you want with detailed performance analysis'
    },
    {
      icon: BarChart3,
      title: 'Advanced Analytics',
      description: 'Get detailed insights into your performance with chapter-wise breakdowns'
    },
    {
      icon: Users,
      title: 'Exclusive Community',
      description: 'Join premium study groups and connect with top performers'
    },
    {
      icon: Shield,
      title: 'Priority Support',
      description: 'Get instant help from our expert team whenever you need it'
    }
  ];

  if (user?.isPremium) {
    return (
      <>
        <Helmet>
          <title>Premium Member - MathSparsh</title>
        </Helmet>

        <div className="min-h-screen py-8 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-effect p-12 rounded-xl"
            >
              <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
              <h1 className="text-4xl font-bold gradient-text mb-4">You're a Premium Member!</h1>
              <p className="text-xl text-gray-300 mb-8">
                Enjoy unlimited access to all MathSparsh features and excel in your JEE preparation.
              </p>
              
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                {premiumBenefits.map((benefit, index) => (
                  <div key={index} className="bg-black/20 p-6 rounded-lg">
                    <benefit.icon className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
                    <h3 className="font-semibold text-white mb-2">{benefit.title}</h3>
                    <p className="text-gray-300 text-sm">{benefit.description}</p>
                  </div>
                ))}
              </div>

              <Button asChild size="lg">
                <a href="/quiz">Continue Learning</a>
              </Button>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Upgrade to Premium - MathSparsh</title>
        <meta name="description" content="Upgrade to MathSparsh Premium for unlimited access to questions, mock tests, PDF downloads, and advanced analytics. Only ₹199 for complete JEE preparation." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Upgrade to Premium
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Unlock the full potential of MathSparsh and accelerate your JEE preparation
            </p>
          </motion.div>

          <PremiumPlans onUpgrade={handleUpgrade} isProcessing={isProcessing} />

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="glass-effect p-8 rounded-xl"
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">Feature Comparison</h3>
            <PremiumFeatures />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-12 text-center"
          >
            <div className="glass-effect p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-white mb-4">Why Choose Premium?</h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
                  <h4 className="font-semibold text-white mb-2">Accelerated Learning</h4>
                  <p className="text-gray-300 text-sm">Access to premium content helps you learn 3x faster</p>
                </div>
                <div className="text-center">
                  <Target className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
                  <h4 className="font-semibold text-white mb-2">Better Results</h4>
                  <p className="text-gray-300 text-sm">Premium users score 25% higher on average</p>
                </div>
                <div className="text-center">
                  <Shield className="w-8 h-8 text-blue-400 mx-auto mb-3" />
                  <h4 className="font-semibold text-white mb-2">Expert Support</h4>
                  <p className="text-gray-300 text-sm">Get help from JEE experts whenever you need it</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default PremiumPage;
