import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Trophy, Medal, Award, Crown, TrendingUp, Target, Clock, Users, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';

const LeaderboardPage = () => {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState('overall');
  const [selectedTimeframe, setSelectedTimeframe] = useState('week');

  useEffect(() => {
    if (!user) {
      window.location.href = '/login';
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center glass-effect p-12 rounded-xl max-w-md">
          <Lock className="w-16 h-16 text-gray-400 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-white mb-4">Login Required</h2>
          <p className="text-gray-300 mb-6">
            Please login to access the leaderboard and compete with fellow JEE aspirants.
          </p>
          <div className="space-y-3">
            <Button asChild className="w-full">
              <a href="/login">Login</a>
            </Button>
            <Button asChild variant="outline" className="w-full">
              <a href="/register">Create Account</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const leaderboardData = {
    overall: [
      { rank: 1, name: 'Arjun Sharma', score: 2847, accuracy: 94, testsCompleted: 45, avatar: 'AS', isPremium: true },
      { rank: 2, name: 'Priya Patel', score: 2756, accuracy: 92, testsCompleted: 42, avatar: 'PP', isPremium: true },
      { rank: 3, name: 'Rahul Kumar', score: 2689, accuracy: 89, testsCompleted: 38, avatar: 'RK', isPremium: false },
      { rank: 4, name: 'Sneha Gupta', score: 2634, accuracy: 91, testsCompleted: 41, avatar: 'SG', isPremium: true },
      { rank: 5, name: 'Vikram Singh', score: 2598, accuracy: 88, testsCompleted: 36, avatar: 'VS', isPremium: false },
      { rank: 6, name: 'Ananya Reddy', score: 2567, accuracy: 90, testsCompleted: 39, avatar: 'AR', isPremium: true },
      { rank: 7, name: 'Karthik Iyer', score: 2534, accuracy: 87, testsCompleted: 35, avatar: 'KI', isPremium: false },
      { rank: 8, name: 'Meera Joshi', score: 2498, accuracy: 89, testsCompleted: 37, avatar: 'MJ', isPremium: false },
      { rank: 9, name: 'Aditya Verma', score: 2467, accuracy: 86, testsCompleted: 34, avatar: 'AV', isPremium: true },
      { rank: 10, name: 'Riya Agarwal', score: 2445, accuracy: 88, testsCompleted: 36, avatar: 'RA', isPremium: false },
    ],
    quiz: [
      { rank: 1, name: 'Priya Patel', score: 1847, accuracy: 96, quizzesCompleted: 78, avatar: 'PP', isPremium: true },
      { rank: 2, name: 'Arjun Sharma', score: 1823, accuracy: 95, quizzesCompleted: 76, avatar: 'AS', isPremium: true },
      { rank: 3, name: 'Sneha Gupta', score: 1789, accuracy: 93, quizzesCompleted: 72, avatar: 'SG', isPremium: true },
    ],
    mockTest: [
      { rank: 1, name: 'Arjun Sharma', score: 1024, accuracy: 92, testsCompleted: 28, avatar: 'AS', isPremium: true },
      { rank: 2, name: 'Rahul Kumar', score: 998, accuracy: 89, testsCompleted: 26, avatar: 'RK', isPremium: false },
      { rank: 3, name: 'Vikram Singh', score: 967, accuracy: 87, testsCompleted: 24, avatar: 'VS', isPremium: false },
    ]
  };

  const userRank = {
    overall: 15,
    quiz: 12,
    mockTest: 18
  };

  const categories = [
    { value: 'overall', label: 'Overall Performance', icon: Trophy },
    { value: 'quiz', label: 'Quiz Champions', icon: Target },
    { value: 'mockTest', label: 'Mock Test Masters', icon: Award }
  ];

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-400" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Award className="w-6 h-6 text-amber-600" />;
      default: return <span className="w-6 h-6 flex items-center justify-center text-gray-400 font-bold">{rank}</span>;
    }
  };

  const getRankBadge = (rank) => {
    if (rank === 1) return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
    if (rank === 2) return 'bg-gradient-to-r from-gray-300 to-gray-500';
    if (rank === 3) return 'bg-gradient-to-r from-amber-400 to-amber-600';
    return 'bg-gray-600';
  };

  const currentData = leaderboardData[selectedCategory] || leaderboardData.overall;

  return (
    <>
      <Helmet>
        <title>Leaderboard - MathSparsh</title>
        <meta name="description" content="Compete with fellow JEE aspirants on the MathSparsh leaderboard. Track rankings in quizzes, mock tests, and overall performance." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Leaderboard
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Compete with fellow JEE aspirants and track your ranking
            </p>
          </motion.div>

          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="md:w-64">
                <SelectValue placeholder="Select Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.value} value={category.value}>
                    {category.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="md:w-48">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect p-6 rounded-xl mb-8"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">{user.name.split(' ').map(n => n[0]).join('')}</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">{user.name}</h3>
                  <p className="text-gray-400">Your Current Rank</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold gradient-text">#{userRank[selectedCategory]}</div>
                <p className="text-gray-400 text-sm">Keep climbing!</p>
              </div>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">2,847</div>
              <div className="text-gray-300 text-sm">Total Participants</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Trophy className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">156</div>
              <div className="text-gray-300 text-sm">Active This Week</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Target className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">89%</div>
              <div className="text-gray-300 text-sm">Avg. Accuracy</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Clock className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">24h</div>
              <div className="text-gray-300 text-sm">Avg. Study Time</div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="p-6 border-b border-white/10">
              <h2 className="text-2xl font-bold text-white">
                {categories.find(c => c.value === selectedCategory)?.label} - {selectedTimeframe === 'week' ? 'This Week' : selectedTimeframe === 'month' ? 'This Month' : 'All Time'}
              </h2>
            </div>

            <div className="divide-y divide-white/10">
              {currentData.map((participant, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`p-6 hover:bg-white/5 transition-colors ${
                    participant.rank <= 3 ? 'bg-gradient-to-r from-white/5 to-transparent' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-3">
                        {getRankIcon(participant.rank)}
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${getRankBadge(participant.rank)}`}>
                          {participant.avatar}
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="text-lg font-semibold text-white">{participant.name}</h3>
                          {participant.isPremium && <Crown className="w-4 h-4 text-yellow-400" />}
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-400">
                          <span>Accuracy: {participant.accuracy}%</span>
                          <span>
                            {selectedCategory === 'quiz' ? `${participant.quizzesCompleted} quizzes` : `${participant.testsCompleted} tests`}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold gradient-text">{participant.score}</div>
                      <div className="text-gray-400 text-sm">points</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8 text-center"
          >
            <div className="glass-effect p-6 rounded-xl">
              <h3 className="text-xl font-bold text-white mb-4">Climb the Leaderboard!</h3>
              <p className="text-gray-300 mb-6">
                Take more quizzes and mock tests to improve your ranking and compete with the best JEE aspirants.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild>
                  <a href="/quiz">Take Quiz</a>
                </Button>
                <Button asChild variant="outline">
                  <a href="/mock-test">Mock Test</a>
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default LeaderboardPage;