import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const QuizResults = ({ questions, answers, score, onResetQuiz, getScoreColor }) => {
  const percentage = Math.round((score / questions.length) * 100);

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4 gradient-text">Quiz Completed!</h1>
          <div className={`text-6xl font-bold mb-4 ${getScoreColor()}`}>
            {percentage}%
          </div>
          <p className="text-xl text-gray-300">
            You scored {score} out of {questions.length} questions
          </p>
        </motion.div>

        <div className="space-y-6">
          {questions.map((question, index) => {
            const userAnswer = answers[index];
            const isCorrect = userAnswer?.isCorrect;

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`p-6 rounded-xl border ${
                  isCorrect ? 'correct-answer' : 'incorrect-answer'
                }`}
              >
                <div className="flex items-start space-x-3 mb-4">
                  {isCorrect ? (
                    <CheckCircle className="w-6 h-6 text-green-400 mt-1" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-400 mt-1" />
                  )}
                  <div className="flex-1">
                    <h3 className="text-lg font-medium text-white mb-2">
                      Question {index + 1}: {question.question}
                    </h3>
                    
                    <div className="space-y-2">
                      {question.options.map((option, optIndex) => (
                        <div
                          key={optIndex}
                          className={`p-2 rounded ${
                            optIndex === question.correct
                              ? 'bg-green-500/20 text-green-300'
                              : optIndex === userAnswer?.selected && !isCorrect
                              ? 'bg-red-500/20 text-red-300'
                              : 'text-gray-400'
                          }`}
                        >
                          {String.fromCharCode(65 + optIndex)}. {option}
                          {optIndex === question.correct && ' ✓'}
                          {optIndex === userAnswer?.selected && !isCorrect && ' ✗'}
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 p-3 bg-blue-500/10 rounded border border-blue-500/30">
                      <p className="text-blue-300 text-sm">
                        <strong>Explanation:</strong> {question.explanation}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="flex justify-center space-x-4 mt-12">
          <Button onClick={onResetQuiz} variant="outline" size="lg">
            <RotateCcw className="w-5 h-5 mr-2" />
            Take Another Quiz
          </Button>
          <Button asChild size="lg">
            <a href="/analytics">View Analytics</a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuizResults;