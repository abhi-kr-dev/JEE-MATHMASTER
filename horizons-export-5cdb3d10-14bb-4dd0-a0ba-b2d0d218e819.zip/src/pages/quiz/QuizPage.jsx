import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { toast } from '@/components/ui/use-toast';
import QuizSetup from './QuizSetup';
import QuizActive from './QuizActive';
import QuizResults from './QuizResults';

const QuizPage = () => {
  const [quizState, setQuizState] = useState('setup');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [timeLimit, setTimeLimit] = useState(10);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(600);
  const [isRunning, setIsRunning] = useState(false);
  const [score, setScore] = useState(0);

  const sampleQuestions = [
    {
      id: 1,
      question: "If the roots of the equation x² - 3x + k = 0 are real and distinct, then the range of k is:",
      options: ['k < 9/4', 'k > 9/4', 'k ≤ 9/4', 'k ≥ 9/4'],
      correct: 0,
      explanation: "For real and distinct roots, discriminant > 0. So 9 - 4k > 0, which gives k < 9/4."
    },
    {
      id: 2,
      question: "Find the derivative of f(x) = sin(x²) with respect to x:",
      options: ['2x cos(x²)', 'cos(x²)', '2x sin(x²)', 'sin(2x)'],
      correct: 0,
      explanation: "Using chain rule: d/dx[sin(x²)] = cos(x²) × d/dx[x²] = cos(x²) × 2x = 2x cos(x²)"
    },
    {
      id: 3,
      question: "The equation of the circle passing through points (1,1), (2,2), and (3,1) is:",
      options: ['x² + y² - 4x - 2y + 1 = 0', 'x² + y² - 3x - 3y + 2 = 0', 'x² + y² - 4x - 2y + 3 = 0', 'x² + y² - 2x - 4y + 1 = 0'],
      correct: 2,
      explanation: "Using the general form and substituting the three points to solve for the coefficients."
    },
    {
      id: 4,
      question: "If |z₁| = 3 and |z₂| = 4, then the maximum value of |z₁ + z₂| is:",
      options: ['1', '5', '7', '12'],
      correct: 2,
      explanation: "By triangle inequality, |z₁ + z₂| ≤ |z₁| + |z₂| = 3 + 4 = 7. Maximum occurs when z₁ and z₂ are in the same direction."
    },
    {
      id: 5,
      question: "The value of ∫₀^π sin²x dx is:",
      options: ['π/4', 'π/2', 'π', '2π'],
      correct: 1,
      explanation: "Using the identity sin²x = (1 - cos(2x))/2 and integrating from 0 to π gives π/2."
    }
  ];

  useEffect(() => {
    let interval;
    if (isRunning && timeLeft > 0 && quizState === 'active') {
      interval = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            handleQuizEnd();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, quizState]);

  const startQuiz = () => {
    if (!selectedTopic || !selectedDifficulty) {
      toast({
        title: "Missing Selection",
        description: "Please select both topic and difficulty level.",
        variant: "destructive"
      });
      return;
    }

    setQuizState('active');
    setTimeLeft(timeLimit * 60);
    setIsRunning(true);
    setCurrentQuestion(0);
    setAnswers([]);
    setScore(0);
  };

  const handleAnswerSelect = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const nextQuestion = () => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = {
      selected: selectedAnswer,
      correct: sampleQuestions[currentQuestion].correct,
      isCorrect: selectedAnswer === sampleQuestions[currentQuestion].correct
    };
    setAnswers(newAnswers);

    if (selectedAnswer === sampleQuestions[currentQuestion].correct) {
      setScore(score + 1);
    }

    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
    } else {
      handleQuizEnd();
    }
  };

  const handleQuizEnd = () => {
    setQuizState('completed');
    setIsRunning(false);
  };

  const resetQuiz = () => {
    setQuizState('setup');
    setCurrentQuestion(0);
    setSelectedAnswer('');
    setAnswers([]);
    setTimeLeft(600);
    setIsRunning(false);
    setScore(0);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getScoreColor = () => {
    const percentage = (score / sampleQuestions.length) * 100;
    if (percentage >= 80) return 'text-green-400';
    if (percentage >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const toggleTimer = () => {
    setIsRunning(!isRunning);
  };

  if (quizState === 'setup') {
    return (
      <>
        <Helmet>
          <title>Interactive Quiz - MathSparsh</title>
          <meta name="description" content="Take interactive mathematics quizzes with timer and instant feedback. Practice JEE Main and Advanced questions with detailed explanations." />
        </Helmet>
        <QuizSetup
          selectedTopic={selectedTopic}
          setSelectedTopic={setSelectedTopic}
          selectedDifficulty={selectedDifficulty}
          setSelectedDifficulty={setSelectedDifficulty}
          timeLimit={timeLimit}
          setTimeLimit={setTimeLimit}
          onStartQuiz={startQuiz}
        />
      </>
    );
  }

  if (quizState === 'active') {
    return (
      <>
        <Helmet>
          <title>Quiz in Progress - MathSparsh</title>
        </Helmet>
        <QuizActive
          currentQuestion={currentQuestion}
          questions={sampleQuestions}
          selectedAnswer={selectedAnswer}
          onAnswerSelect={handleAnswerSelect}
          timeLeft={timeLeft}
          isRunning={isRunning}
          onToggleTimer={toggleTimer}
          onNextQuestion={nextQuestion}
          score={score}
          formatTime={formatTime}
        />
      </>
    );
  }

  if (quizState === 'completed') {
    return (
      <>
        <Helmet>
          <title>Quiz Results - MathSparsh</title>
        </Helmet>
        <QuizResults
          questions={sampleQuestions}
          answers={answers}
          score={score}
          onResetQuiz={resetQuiz}
          getScoreColor={getScoreColor}
        />
      </>
    );
  }
};

export default QuizPage;