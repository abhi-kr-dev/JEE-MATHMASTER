import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const QuizActive = ({
  currentQuestion,
  questions,
  selectedAnswer,
  onAnswerSelect,
  timeLeft,
  isRunning,
  onToggleTimer,
  onNextQuestion,
  score,
  formatTime
}) => {
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <div className={`flex items-center space-x-2 ${timeLeft < 60 ? 'timer-pulse' : ''}`}>
              <Clock className={`w-5 h-5 ${timeLeft < 60 ? 'text-red-400' : 'text-emerald-400'}`} />
              <span className={`text-lg font-mono ${timeLeft < 60 ? 'text-red-400' : 'text-white'}`}>
                {formatTime(timeLeft)}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onToggleTimer}
            >
              {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
          </div>
          
          <div className="text-white">
            Question {currentQuestion + 1} of {questions.length}
          </div>
        </div>

        <div className="mb-6">
          <Progress value={progress} className="h-2" />
        </div>

        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          className="quiz-card p-8 rounded-xl"
        >
          <h2 className="text-xl font-medium text-white mb-6">
            {question.question}
          </h2>

          <div className="space-y-3">
            {question.options.map((option, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onAnswerSelect(index)}
                className={`w-full p-4 text-left rounded-lg border transition-all ${
                  selectedAnswer === index
                    ? 'selected-answer'
                    : 'bg-black/20 border-gray-600 hover:border-gray-500'
                }`}
              >
                <span className="text-gray-300 mr-3">
                  {String.fromCharCode(65 + index)}.
                </span>
                <span className="text-white">{option}</span>
              </motion.button>
            ))}
          </div>

          <div className="flex justify-between items-center mt-8">
            <div className="text-gray-400">
              Score: {score}/{currentQuestion + (selectedAnswer !== '' ? 1 : 0)}
            </div>
            <Button
              onClick={onNextQuestion}
              disabled={selectedAnswer === ''}
              size="lg"
            >
              {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default QuizActive;