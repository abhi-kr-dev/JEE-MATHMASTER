import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { User, Calendar, Award, Download, BookOpen, Target, Timer, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';
import { toast } from '@/components/ui/use-toast';

const ProfilePage = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Please login to view your profile</h2>
          <Button onClick={() => window.location.href = '/login'}>
            Go to Login
          </Button>
        </div>
      </div>
    );
  }

  const handleUpgradeToPremium = () => {
    toast({
      title: "🚧 Premium Upgrade Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const stats = [
    { label: 'Questions Solved', value: '1,247', icon: BookOpen, color: 'text-blue-400' },
    { label: 'Quiz Accuracy', value: '78%', icon: Target, color: 'text-green-400' },
    { label: 'Mock Tests Taken', value: '23', icon: Timer, color: 'text-purple-400' },
    { label: 'Study Streak', value: '15 days', icon: Award, color: 'text-yellow-400' }
  ];

  const recentActivity = [
    { activity: 'Completed Calculus Quiz', score: '18/20', accuracy: 90, date: '2025-06-24', type: 'quiz' },
    { activity: 'JEE Main Mock Test 3', score: '89/120', accuracy: 74, date: '2025-06-23', type: 'test' },
    { activity: 'Algebra Practice Session', score: '45/50', accuracy: 90, date: '2025-06-22', type: 'practice' },
    { activity: 'Trigonometry Formula Review', score: 'Completed', accuracy: null, date: '2025-06-21', type: 'study' }
  ];

  const achievements = [
    { title: 'Quiz Master', description: 'Completed 50 quizzes', icon: Target, earned: true },
    { title: 'Speed Demon', description: 'Solved 100 questions in under 2 hours', icon: Timer, earned: true },
    { title: 'Consistency King', description: 'Maintained 7-day study streak', icon: Award, earned: true },
    { title: 'Mock Test Champion', description: 'Scored 90%+ in 5 mock tests', icon: BarChart3, earned: false }
  ];

  const getActivityIcon = (type) => {
    switch (type) {
      case 'quiz': return Timer;
      case 'test': return Target;
      case 'practice': return BookOpen;
      case 'study': return Award;
      default: return BookOpen;
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'quiz': return 'text-purple-400';
      case 'test': return 'text-blue-400';
      case 'practice': return 'text-emerald-400';
      case 'study': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <>
      <Helmet>
        <title>Profile - MathSparsh</title>
        <meta name="description" content="View your MathSparsh profile, track your JEE preparation progress, achievements, and manage your account settings." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-effect p-8 rounded-xl mb-8"
          >
            <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
              <div className="w-24 h-24 bg-gradient-to-r from-emerald-500 to-blue-600 rounded-full flex items-center justify-center">
                <User className="w-12 h-12 text-white" />
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-bold text-white mb-2">{user.name}</h1>
                <p className="text-gray-300 mb-2">{user.email}</p>
                <div className="flex items-center justify-center md:justify-start space-x-2 text-gray-400">
                  <Calendar className="w-4 h-4" />
                  <span>Joined {new Date(user.joinedDate).toLocaleDateString()}</span>
                </div>
                {user.isPremium && (
                  <div className="mt-2">
                    <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-3 py-1 rounded-full text-sm font-medium">
                      Premium Member
                    </span>
                  </div>
                )}
              </div>

              <div className="flex flex-col space-y-2">
                {!user.isPremium && (
                  <Button onClick={handleUpgradeToPremium} className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                    Upgrade to Premium
                  </Button>
                )}
                <Button variant="outline" onClick={logout}>
                  Logout
                </Button>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            {stats.map((stat, index) => (
              <div key={index} className="question-card p-6 rounded-xl text-center">
                <div className={`w-12 h-12 mx-auto mb-4 rounded-lg bg-black/20 flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-gray-300 text-sm">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Recent Activity</h2>
              
              <div className="space-y-4">
                {recentActivity.map((activity, index) => {
                  const ActivityIcon = getActivityIcon(activity.type);
                  return (
                    <div key={index} className="bg-black/20 p-4 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <ActivityIcon className={`w-5 h-5 mt-1 ${getActivityColor(activity.type)}`} />
                        <div className="flex-1">
                          <h3 className="font-medium text-white">{activity.activity}</h3>
                          <div className="flex items-center justify-between mt-1">
                            <div className="flex items-center space-x-4">
                              <span className="text-gray-300 text-sm">Score: {activity.score}</span>
                              {activity.accuracy && (
                                <span className="text-emerald-400 text-sm">{activity.accuracy}% accuracy</span>
                              )}
                            </div>
                            <span className="text-gray-400 text-sm">
                              {new Date(activity.date).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 text-center">
                <Button variant="outline" asChild>
                  <a href="/analytics">View Detailed Analytics</a>
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Achievements</h2>
              
              <div className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className={`p-4 rounded-lg border ${
                    achievement.earned 
                      ? 'bg-emerald-500/10 border-emerald-500/30' 
                      : 'bg-gray-500/10 border-gray-500/30'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        achievement.earned 
                          ? 'bg-emerald-500/20' 
                          : 'bg-gray-500/20'
                      }`}>
                        <achievement.icon className={`w-5 h-5 ${
                          achievement.earned 
                            ? 'text-emerald-400' 
                            : 'text-gray-400'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <h3 className={`font-medium ${
                          achievement.earned ? 'text-white' : 'text-gray-400'
                        }`}>
                          {achievement.title}
                        </h3>
                        <p className="text-gray-400 text-sm">{achievement.description}</p>
                      </div>
                      {achievement.earned && (
                        <Award className="w-5 h-5 text-yellow-400" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="glass-effect p-6 rounded-xl"
          >
            <h2 className="text-2xl font-bold text-white mb-6">Quick Actions</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button asChild className="h-16 flex-col space-y-1">
                <a href="/quiz">
                  <Timer className="w-5 h-5" />
                  <span>Start Quiz</span>
                </a>
              </Button>
              <Button asChild variant="outline" className="h-16 flex-col space-y-1">
                <a href="/mock-test">
                  <Target className="w-5 h-5" />
                  <span>Mock Test</span>
                </a>
              </Button>
              <Button asChild variant="outline" className="h-16 flex-col space-y-1">
                <a href="/formulas">
                  <BookOpen className="w-5 h-5" />
                  <span>Formulas</span>
                </a>
              </Button>
              <Button asChild variant="outline" className="h-16 flex-col space-y-1">
                <a href="/analytics">
                  <BarChart3 className="w-5 h-5" />
                  <span>Analytics</span>
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;