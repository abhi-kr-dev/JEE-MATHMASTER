import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Timer, Play, Pause, RotateCcw, CheckCircle, XCircle, Clock, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const QuizPage = () => {
  const [quizState, setQuizState] = useState('setup');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [timeLimit, setTimeLimit] = useState(10);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(600);
  const [isRunning, setIsRunning] = useState(false);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);

  const topics = [
    'Algebra', 'Calculus', 'Coordinate Geometry', 'Trigonometry', 'Vectors & 3D Geometry'
  ];

  const difficulties = [
    { value: 'basic', label: 'Basic' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  const sampleQuestions = [
    {
      id: 1,
      question: "If the roots of the equation x² - 3x + k = 0 are real and distinct, then the range of k is:",
      options: ['k < 9/4', 'k > 9/4', 'k ≤ 9/4', 'k ≥ 9/4'],
      correct: 0,
      explanation: "For real and distinct roots, discriminant > 0. So 9 - 4k > 0, which gives k < 9/4."
    },
    {
      id: 2,
      question: "Find the derivative of f(x) = sin(x²) with respect to x:",
      options: ['2x cos(x²)', 'cos(x²)', '2x sin(x²)', 'sin(2x)'],
      correct: 0,
      explanation: "Using chain rule: d/dx[sin(x²)] = cos(x²) × d/dx[x²] = cos(x²) × 2x = 2x cos(x²)"
    },
    {
      id: 3,
      question: "The equation of the circle passing through points (1,1), (2,2), and (3,1) is:",
      options: ['x² + y² - 4x - 2y + 1 = 0', 'x² + y² - 3x - 3y + 2 = 0', 'x² + y² - 4x - 2y + 3 = 0', 'x² + y² - 2x - 4y + 1 = 0'],
      correct: 2,
      explanation: "Using the general form and substituting the three points to solve for the coefficients."
    },
    {
      id: 4,
      question: "If |z₁| = 3 and |z₂| = 4, then the maximum value of |z₁ + z₂| is:",
      options: ['1', '5', '7', '12'],
      correct: 2,
      explanation: "By triangle inequality, |z₁ + z₂| ≤ |z₁| + |z₂| = 3 + 4 = 7. Maximum occurs when z₁ and z₂ are in the same direction."
    },
    {
      id: 5,
      question: "The value of ∫₀^π sin²x dx is:",
      options: ['π/4', 'π/2', 'π', '2π'],
      correct: 1,
      explanation: "Using the identity sin²x = (1 - cos(2x))/2 and integrating from 0 to π gives π/2."
    }
  ];

  useEffect(() => {
    let interval;
    if (isRunning && timeLeft > 0 && quizState === 'active') {
      interval = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            handleQuizEnd();
            return 0;
          }
          return time - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft, quizState]);

  const startQuiz = () => {
    if (!selectedTopic || !selectedDifficulty) {
      toast({
        title: "Missing Selection",
        description: "Please select both topic and difficulty level.",
        variant: "destructive"
      });
      return;
    }

    setQuizState('active');
    setTimeLeft(timeLimit * 60);
    setIsRunning(true);
    setCurrentQuestion(0);
    setAnswers([]);
    setScore(0);
    setShowResults(false);
  };

  const handleAnswerSelect = (answerIndex) => {
    setSelectedAnswer(answerIndex);
  };

  const nextQuestion = () => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = {
      selected: selectedAnswer,
      correct: sampleQuestions[currentQuestion].correct,
      isCorrect: selectedAnswer === sampleQuestions[currentQuestion].correct
    };
    setAnswers(newAnswers);

    if (selectedAnswer === sampleQuestions[currentQuestion].correct) {
      setScore(score + 1);
    }

    if (currentQuestion < sampleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
    } else {
      handleQuizEnd();
    }
  };

  const handleQuizEnd = () => {
    setQuizState('completed');
    setIsRunning(false);
    setShowResults(true);
  };

  const resetQuiz = () => {
    setQuizState('setup');
    setCurrentQuestion(0);
    setSelectedAnswer('');
    setAnswers([]);
    setTimeLeft(600);
    setIsRunning(false);
    setScore(0);
    setShowResults(false);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getScoreColor = () => {
    const percentage = (score / sampleQuestions.length) * 100;
    if (percentage >= 80) return 'text-green-400';
    if (percentage >= 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  if (quizState === 'setup') {
    return (
      <>
        <Helmet>
          <title>Interactive Quiz - MathSparsh</title>
          <meta name="description" content="Take interactive mathematics quizzes with timer and instant feedback. Practice JEE Main and Advanced questions with detailed explanations." />
        </Helmet>

        <div className="min-h-screen py-8 px-4">
          <div className="container mx-auto max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
                Interactive Quiz
              </h1>
              <p className="text-xl text-gray-300">
                Test your knowledge with timed quizzes and instant feedback
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="glass-effect p-8 rounded-xl"
            >
              <div className="space-y-6">
                <div>
                  <label className="text-white mb-2 block font-medium">Select Topic</label>
                  <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a topic" />
                    </SelectTrigger>
                    <SelectContent>
                      {topics.map((topic) => (
                        <SelectItem key={topic} value={topic}>{topic}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white mb-2 block font-medium">Difficulty Level</label>
                  <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose difficulty" />
                    </SelectTrigger>
                    <SelectContent>
                      {difficulties.map((diff) => (
                        <SelectItem key={diff.value} value={diff.value}>{diff.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white mb-2 block font-medium">Time Limit (minutes)</label>
                  <Select value={timeLimit.toString()} onValueChange={(value) => setTimeLimit(parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="10">10 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="20">20 minutes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={startQuiz} className="w-full" size="lg">
                  <Play className="w-5 h-5 mr-2" />
                  Start Quiz
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  if (quizState === 'active') {
    const question = sampleQuestions[currentQuestion];
    const progress = ((currentQuestion + 1) / sampleQuestions.length) * 100;

    return (
      <>
        <Helmet>
          <title>Quiz in Progress - MathSparsh</title>
        </Helmet>

        <div className="min-h-screen py-8 px-4">
          <div className="container mx-auto max-w-4xl">
            <div className="flex justify-between items-center mb-8">
              <div className="flex items-center space-x-4">
                <div className={`flex items-center space-x-2 ${timeLeft < 60 ? 'timer-pulse' : ''}`}>
                  <Clock className={`w-5 h-5 ${timeLeft < 60 ? 'text-red-400' : 'text-emerald-400'}`} />
                  <span className={`text-lg font-mono ${timeLeft < 60 ? 'text-red-400' : 'text-white'}`}>
                    {formatTime(timeLeft)}
                  </span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsRunning(!isRunning)}
                >
                  {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
              </div>
              
              <div className="text-white">
                Question {currentQuestion + 1} of {sampleQuestions.length}
              </div>
            </div>

            <div className="mb-6">
              <Progress value={progress} className="h-2" />
            </div>

            <motion.div
              key={currentQuestion}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              className="quiz-card p-8 rounded-xl"
            >
              <h2 className="text-xl font-medium text-white mb-6">
                {question.question}
              </h2>

              <div className="space-y-3">
                {question.options.map((option, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full p-4 text-left rounded-lg border transition-all ${
                      selectedAnswer === index
                        ? 'selected-answer'
                        : 'bg-black/20 border-gray-600 hover:border-gray-500'
                    }`}
                  >
                    <span className="text-gray-300 mr-3">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    <span className="text-white">{option}</span>
                  </motion.button>
                ))}
              </div>

              <div className="flex justify-between items-center mt-8">
                <div className="text-gray-400">
                  Score: {score}/{currentQuestion + (selectedAnswer !== '' ? 1 : 0)}
                </div>
                <Button
                  onClick={nextQuestion}
                  disabled={selectedAnswer === ''}
                  size="lg"
                >
                  {currentQuestion === sampleQuestions.length - 1 ? 'Finish Quiz' : 'Next Question'}
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </>
    );
  }

  if (quizState === 'completed') {
    const percentage = Math.round((score / sampleQuestions.length) * 100);

    return (
      <>
        <Helmet>
          <title>Quiz Results - MathSparsh</title>
        </Helmet>

        <div className="min-h-screen py-8 px-4">
          <div className="container mx-auto max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h1 className="text-4xl font-bold mb-4 gradient-text">Quiz Completed!</h1>
              <div className={`text-6xl font-bold mb-4 ${getScoreColor()}`}>
                {percentage}%
              </div>
              <p className="text-xl text-gray-300">
                You scored {score} out of {sampleQuestions.length} questions
              </p>
            </motion.div>

            <div className="space-y-6">
              {sampleQuestions.map((question, index) => {
                const userAnswer = answers[index];
                const isCorrect = userAnswer?.isCorrect;

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-6 rounded-xl border ${
                      isCorrect ? 'correct-answer' : 'incorrect-answer'
                    }`}
                  >
                    <div className="flex items-start space-x-3 mb-4">
                      {isCorrect ? (
                        <CheckCircle className="w-6 h-6 text-green-400 mt-1" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-400 mt-1" />
                      )}
                      <div className="flex-1">
                        <h3 className="text-lg font-medium text-white mb-2">
                          Question {index + 1}: {question.question}
                        </h3>
                        
                        <div className="space-y-2">
                          {question.options.map((option, optIndex) => (
                            <div
                              key={optIndex}
                              className={`p-2 rounded ${
                                optIndex === question.correct
                                  ? 'bg-green-500/20 text-green-300'
                                  : optIndex === userAnswer?.selected && !isCorrect
                                  ? 'bg-red-500/20 text-red-300'
                                  : 'text-gray-400'
                              }`}
                            >
                              {String.fromCharCode(65 + optIndex)}. {option}
                              {optIndex === question.correct && ' ✓'}
                              {optIndex === userAnswer?.selected && !isCorrect && ' ✗'}
                            </div>
                          ))}
                        </div>

                        <div className="mt-4 p-3 bg-blue-500/10 rounded border border-blue-500/30">
                          <p className="text-blue-300 text-sm">
                            <strong>Explanation:</strong> {question.explanation}
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <div className="flex justify-center space-x-4 mt-12">
              <Button onClick={resetQuiz} variant="outline" size="lg">
                <RotateCcw className="w-5 h-5 mr-2" />
                Take Another Quiz
              </Button>
              <Button asChild size="lg">
                <a href="/analytics">View Analytics</a>
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  }
};

export default QuizPage;