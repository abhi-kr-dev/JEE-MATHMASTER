import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowRight, BookOpen, Timer, Target, FileText, Archive, Crown, Users, Award, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';

const HomePage = () => {
  const { user } = useAuth();

  const features = [
    {
      icon: BookOpen,
      title: 'Comprehensive Question Bank',
      description: 'Access 15,000+ carefully curated JEE Main & Advanced mathematics questions across all topics',
      href: '/questions',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Timer,
      title: 'Interactive Quizzes',
      description: 'Test your knowledge with topic-wise quizzes and get instant feedback on your performance',
      href: '/quiz',
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Target,
      title: 'Mock Tests',
      description: 'Practice with JEE-pattern mock tests and analyze your performance with detailed insights',
      href: '/mock-test',
      color: 'from-emerald-500 to-teal-500'
    },
    {
      icon: FileText,
      title: 'Formula Sheets',
      description: 'Quick access to all important formulas and concepts for last-minute revision',
      href: '/formulas',
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: Archive,
      title: 'Previous Year Papers',
      description: 'Solve authentic JEE Main & Advanced papers from previous years with solutions',
      href: '/previous-papers',
      color: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Crown,
      title: 'Premium Features',
      description: 'Unlock unlimited access, PDF downloads, and advanced analytics with premium membership',
      href: '/premium',
      color: 'from-yellow-500 to-orange-500'
    }
  ];

  const stats = [
    { number: '15,000+', label: 'Practice Questions', icon: BookOpen },
    { number: '2,500+', label: 'Active Students', icon: Users },
    { number: '95%', label: 'Success Rate', icon: Award },
    { number: '24/7', label: 'Support Available', icon: TrendingUp }
  ];

  return (
    <>
      <Helmet>
        <title>MathSparsh - Your Ultimate JEE Main & Advanced Mathematics Platform</title>
        <meta name="description" content="Master JEE Main and Advanced mathematics with MathSparsh - comprehensive question bank, interactive quizzes, mock tests, formula sheets, and performance analytics." />
      </Helmet>

      <div className="min-h-screen">
        <section className="py-20 px-4">
          <div className="container mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text">
                Master JEE Mathematics
              </h1>
              <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
                Your comprehensive platform for JEE Main & Advanced mathematics preparation with 15,000+ questions, 
                interactive quizzes, and detailed analytics.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Button size="lg" asChild className="text-lg px-8 py-4">
                  <a href="/questions">
                    Start Practicing
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </a>
                </Button>
                <Button size="lg" variant="outline" asChild className="text-lg px-8 py-4">
                  <a href="/quiz">Take a Quiz</a>
                </Button>
              </div>

              <div className="grid md:grid-cols-4 gap-6 mb-16">
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 + 0.3 }}
                    className="glass-effect p-6 rounded-xl text-center"
                  >
                    <stat.icon className="w-8 h-8 mx-auto mb-3 text-emerald-400" />
                    <div className="text-3xl font-bold text-white mb-2">{stat.number}</div>
                    <div className="text-gray-300">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        <section className="py-20 px-4">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">
                Everything You Need to Excel
              </h2>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Comprehensive tools and resources designed specifically for JEE mathematics preparation
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 + 0.4 }}
                  className="group"
                >
                  <a href={feature.href} className="block">
                    <div className="question-card p-8 rounded-xl h-full transition-all duration-300 group-hover:scale-105">
                      <div className={`w-16 h-16 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mb-6`}>
                        <feature.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                      <p className="text-gray-300 mb-6">{feature.description}</p>
                      <div className="flex items-center text-emerald-400 font-medium">
                        Explore
                        <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </div>
                    </div>
                  </a>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {!user && (
          <section className="py-20 px-4">
            <div className="container mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="glass-effect p-12 rounded-xl text-center"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-6 gradient-text">
                  Ready to Start Your JEE Journey?
                </h2>
                <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                  Join thousands of successful JEE aspirants who have improved their mathematics scores with MathSparsh
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" asChild className="text-lg px-8 py-4">
                    <a href="/register">Create Free Account</a>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="text-lg px-8 py-4">
                    <a href="/login">Login</a>
                  </Button>
                </div>
              </motion.div>
            </div>
          </section>
        )}

        {user && (
          <section className="py-20 px-4">
            <div className="container mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="glass-effect p-12 rounded-xl text-center"
              >
                <h2 className="text-3xl md:text-4xl font-bold mb-6 gradient-text">
                  Welcome back, {user.name}!
                </h2>
                <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                  Continue your JEE preparation journey with personalized practice and detailed analytics
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" asChild className="text-lg px-8 py-4">
                    <a href="/quiz">Continue Learning</a>
                  </Button>
                  {!user.isPremium && (
                    <Button size="lg" variant="outline" asChild className="text-lg px-8 py-4">
                      <a href="/premium">Upgrade to Premium</a>
                    </Button>
                  )}
                </div>
              </motion.div>
            </div>
          </section>
        )}
      </div>
    </>
  );
};

export default HomePage;