
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Download, BookOpen, Target, Hash, FileText, Grid3X3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';
import { toast } from '@/components/ui/use-toast';
import { useQuestionLogic } from '@/hooks/useQuestionLogic';
import QuestionFilters from '@/components/questions/QuestionFilters';
import QuestionCard from '@/components/questions/QuestionCard';

const QuestionsPage = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('all');
  const [selectedSubtopic, setSelectedSubtopic] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [questions, setQuestions] = useState([]);
  const [filteredQuestions, setFilteredQuestions] = useState([]);

  const {
    answeredQuestions,
    showSolutions,
    handleAnswerSelect,
    handleNumericalAnswer,
    handleMatrixMatch,
    isCorrectAnswer,
    getAnswerStatus
  } = useQuestionLogic(questions);

  const topics = {
    'algebra': {
      name: 'Algebra',
      subtopics: ['Quadratic Equations', 'Complex Numbers', 'Sequences & Series', 'Permutations & Combinations']
    },
    'calculus': {
      name: 'Calculus',
      subtopics: ['Limits', 'Derivatives', 'Integrals', 'Differential Equations']
    },
    'coordinate-geometry': {
      name: 'Coordinate Geometry',
      subtopics: ['Straight Lines', 'Circles', 'Parabola', 'Ellipse', 'Hyperbola']
    },
    'trigonometry': {
      name: 'Trigonometry',
      subtopics: ['Basic Trigonometry', 'Inverse Trigonometry', 'Trigonometric Equations']
    },
    'vectors': {
      name: 'Vectors & 3D Geometry',
      subtopics: ['Vector Algebra', 'Scalar Triple Product', 'Vector Triple Product', '3D Lines & Planes']
    }
  };

  const questionTypes = [
    { value: 'single-correct', label: 'Single Correct Answer', icon: Target },
    { value: 'multiple-correct', label: 'Multiple Correct Answer', icon: BookOpen },
    { value: 'numerical', label: 'Numerical Type', icon: Hash },
    { value: 'paragraph', label: 'Paragraph Type', icon: FileText },
    { value: 'matrix-match', label: 'Matrix Match', icon: Grid3X3 }
  ];

  const levels = [
    { value: 'basic', label: 'Basic', color: 'text-green-400' },
    { value: 'intermediate', label: 'Intermediate', color: 'text-yellow-400' },
    { value: 'advanced', label: 'Advanced', color: 'text-red-400' }
  ];

  useEffect(() => {
    const mockQuestions = [
      {
        id: 1,
        question: "If the roots of the equation x² - 3x + k = 0 are real and distinct, then the range of k is:",
        topic: 'algebra',
        subtopic: 'Quadratic Equations',
        type: 'single-correct',
        level: 'basic',
        options: ['k < 9/4', 'k > 9/4', 'k ≤ 9/4', 'k ≥ 9/4'],
        correctAnswer: [0],
        solution: "For real and distinct roots, discriminant > 0. So 9 - 4k > 0, which gives k < 9/4."
      },
      {
        id: 2,
        question: "Find the derivative of f(x) = sin(x²) with respect to x:",
        topic: 'calculus',
        subtopic: 'Derivatives',
        type: 'single-correct',
        level: 'intermediate',
        options: ['2x cos(x²)', 'cos(x²)', '2x sin(x²)', 'sin(2x)'],
        correctAnswer: [0],
        solution: "Using chain rule: d/dx[sin(x²)] = cos(x²) × d/dx[x²] = cos(x²) × 2x = 2x cos(x²)"
      },
      {
        id: 3,
        question: "Which of the following are properties of complex numbers? (Select all correct options)",
        topic: 'algebra',
        subtopic: 'Complex Numbers',
        type: 'multiple-correct',
        level: 'intermediate',
        options: ['|z₁ + z₂| ≤ |z₁| + |z₂|', '|z₁z₂| = |z₁||z₂|', 'z + z̄ = 2Re(z)', 'z - z̄ = 2iIm(z)'],
        correctAnswer: [0, 1, 2, 3],
        solution: "All options are correct: Triangle inequality, modulus property, real part formula, and imaginary part formula."
      },
      {
        id: 4,
        question: "If |z₁| = 3 and |z₂| = 4, then the maximum value of |z₁ + z₂| is:",
        topic: 'algebra',
        subtopic: 'Complex Numbers',
        type: 'numerical',
        level: 'intermediate',
        answer: 7,
        solution: "By triangle inequality, |z₁ + z₂| ≤ |z₁| + |z₂| = 3 + 4 = 7. Maximum occurs when z₁ and z₂ are in the same direction."
      },
      {
        id: 5,
        question: "Match the following functions with their derivatives:",
        topic: 'calculus',
        subtopic: 'Derivatives',
        type: 'matrix-match',
        level: 'advanced',
        columnA: ['sin(x)', 'cos(x)', 'tan(x)', 'ln(x)'],
        columnB: ['sec²(x)', '1/x', 'cos(x)', '-sin(x)'],
        correctMatches: [[0, 2], [1, 3], [2, 0], [3, 1]],
        solution: "sin(x) → cos(x), cos(x) → -sin(x), tan(x) → sec²(x), ln(x) → 1/x"
      }
    ];
    setQuestions(mockQuestions);
    setFilteredQuestions(mockQuestions);
  }, []);

  useEffect(() => {
    let filtered = questions.filter(q => {
      const matchesSearch = q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           q.subtopic.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTopic = selectedTopic === 'all' || q.topic === selectedTopic;
      const matchesSubtopic = selectedSubtopic === 'all' || q.subtopic === selectedSubtopic;
      const matchesLevel = selectedLevel === 'all' || q.level === selectedLevel;
      const matchesType = selectedType === 'all' || q.type === selectedType;

      return matchesSearch && matchesTopic && matchesSubtopic && matchesLevel && matchesType;
    });

    setFilteredQuestions(filtered);
  }, [searchTerm, selectedTopic, selectedSubtopic, selectedLevel, selectedType, questions]);

  const handleDownloadPDF = () => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please login to download PDF files.",
        variant: "destructive"
      });
      return;
    }

    if (!user.isPremium) {
      toast({
        title: "Premium Feature",
        description: "PDF downloads are available for premium members only. Upgrade to access this feature!",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "🚧 PDF Download Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const getQuestionTypeIcon = (type) => {
    const questionType = questionTypes.find(qt => qt.value === type);
    return questionType ? questionType.icon : Target;
  };

  const getLevelColor = (level) => {
    const levelObj = levels.find(l => l.value === level);
    return levelObj ? levelObj.color : 'text-gray-400';
  };

  return (
    <>
      <Helmet>
        <title>JEE Mathematics Questions - Practice & Download | MathSparsh</title>
        <meta name="description" content="Practice JEE Main and Advanced mathematics questions with our comprehensive question bank. Filter by topic, difficulty level, and question type. Download PDFs for offline study." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              JEE Mathematics Question Bank
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Practice with our comprehensive collection of JEE Main & Advanced mathematics questions
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect p-6 rounded-xl mb-8"
          >
            <QuestionFilters
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              selectedTopic={selectedTopic}
              setSelectedTopic={setSelectedTopic}
              selectedSubtopic={selectedSubtopic}
              setSelectedSubtopic={setSelectedSubtopic}
              selectedLevel={selectedLevel}
              setSelectedLevel={setSelectedLevel}
              selectedType={selectedType}
              setSelectedType={setSelectedType}
              topics={topics}
              levels={levels}
              questionTypes={questionTypes}
            />

            <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
              <div className="text-gray-300">
                Showing {filteredQuestions.length} of {questions.length} questions
              </div>
              <Button onClick={handleDownloadPDF} className="flex items-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Download PDF</span>
              </Button>
            </div>
          </motion.div>

          <div className="space-y-6">
            {filteredQuestions.map((question, index) => {
              const userAnswer = answeredQuestions[question.id];
              const answerStatus = getAnswerStatus(question, userAnswer);
              const showSolution = showSolutions[question.id];
              
              return (
                <QuestionCard
                  key={question.id}
                  question={question}
                  index={index}
                  userAnswer={userAnswer}
                  showSolution={showSolution}
                  answerStatus={answerStatus}
                  onAnswerSelect={handleAnswerSelect}
                  onNumericalAnswer={handleNumericalAnswer}
                  onMatrixMatch={handleMatrixMatch}
                  isCorrectAnswer={isCorrectAnswer}
                  getAnswerStatus={getAnswerStatus}
                  getQuestionTypeIcon={getQuestionTypeIcon}
                  getLevelColor={getLevelColor}
                  questionTypes={questionTypes}
                  levels={levels}
                />
              );
            })}
          </div>

          {filteredQuestions.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-300 mb-2">No questions found</h3>
              <p className="text-gray-400">Try adjusting your search criteria or filters</p>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
};

export default QuestionsPage;
