import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { BookOpen, Download, Search, Star, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const FormulaSheetPage = () => {
  const [selectedTopic, setSelectedTopic] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedFormula, setCopiedFormula] = useState('');

  const formulaCategories = {
    algebra: {
      name: 'Algebra',
      formulas: [
        {
          id: 1,
          title: 'Quadratic Formula',
          formula: 'x = (-b ± √(b² - 4ac)) / 2a',
          description: 'For equation ax² + bx + c = 0',
          important: true
        },
        {
          id: 2,
          title: 'Sum of AP',
          formula: 'S_n = n/2 [2a + (n-1)d]',
          description: 'Sum of first n terms of arithmetic progression'
        },
        {
          id: 3,
          title: 'Sum of GP',
          formula: 'S_n = a(r^n - 1)/(r - 1) for r ≠ 1',
          description: 'Sum of first n terms of geometric progression'
        },
        {
          id: 4,
          title: 'Binomial Theorem',
          formula: '(a + b)^n = Σ(k=0 to n) C(n,k) a^(n-k) b^k',
          description: 'Expansion of (a + b)^n'
        }
      ]
    },
    calculus: {
      name: 'Calculus',
      formulas: [
        {
          id: 5,
          title: 'Product Rule',
          formula: 'd/dx[f(x)g(x)] = f\'(x)g(x) + f(x)g\'(x)',
          description: 'Derivative of product of two functions',
          important: true
        },
        {
          id: 6,
          title: 'Chain Rule',
          formula: 'd/dx[f(g(x))] = f\'(g(x)) · g\'(x)',
          description: 'Derivative of composite function'
        },
        {
          id: 7,
          title: 'Integration by Parts',
          formula: '∫u dv = uv - ∫v du',
          description: 'Integration technique for products',
          important: true
        },
        {
          id: 8,
          title: 'Fundamental Theorem',
          formula: '∫[a to b] f(x)dx = F(b) - F(a)',
          description: 'Where F\'(x) = f(x)'
        }
      ]
    },
    trigonometry: {
      name: 'Trigonometry',
      formulas: [
        {
          id: 9,
          title: 'Pythagorean Identity',
          formula: 'sin²θ + cos²θ = 1',
          description: 'Basic trigonometric identity',
          important: true
        },
        {
          id: 10,
          title: 'Double Angle (sin)',
          formula: 'sin(2θ) = 2sin(θ)cos(θ)',
          description: 'Double angle formula for sine'
        },
        {
          id: 11,
          title: 'Double Angle (cos)',
          formula: 'cos(2θ) = cos²θ - sin²θ',
          description: 'Double angle formula for cosine'
        },
        {
          id: 12,
          title: 'Sum to Product',
          formula: 'sin(A) + sin(B) = 2sin((A+B)/2)cos((A-B)/2)',
          description: 'Converting sum to product'
        }
      ]
    },
    coordinate: {
      name: 'Coordinate Geometry',
      formulas: [
        {
          id: 13,
          title: 'Distance Formula',
          formula: 'd = √[(x₂-x₁)² + (y₂-y₁)²]',
          description: 'Distance between two points',
          important: true
        },
        {
          id: 14,
          title: 'Section Formula',
          formula: '((mx₂+nx₁)/(m+n), (my₂+ny₁)/(m+n))',
          description: 'Point dividing line segment in ratio m:n'
        },
        {
          id: 15,
          title: 'Circle Equation',
          formula: '(x-h)² + (y-k)² = r²',
          description: 'Standard form of circle with center (h,k) and radius r',
          important: true
        },
        {
          id: 16,
          title: 'Slope Formula',
          formula: 'm = (y₂-y₁)/(x₂-x₁)',
          description: 'Slope of line through two points'
        }
      ]
    },
    vectors: {
      name: 'Vectors & 3D',
      formulas: [
        {
          id: 17,
          title: 'Dot Product',
          formula: 'a⃗ · b⃗ = |a⃗||b⃗|cos(θ)',
          description: 'Scalar product of two vectors',
          important: true
        },
        {
          id: 18,
          title: 'Cross Product Magnitude',
          formula: '|a⃗ × b⃗| = |a⃗||b⃗|sin(θ)',
          description: 'Magnitude of vector product'
        },
        {
          id: 19,
          title: 'Distance from Point to Plane',
          formula: 'd = |ax₀ + by₀ + cz₀ + d|/√(a² + b² + c²)',
          description: 'Distance from point (x₀,y₀,z₀) to plane ax+by+cz+d=0'
        },
        {
          id: 20,
          title: 'Volume of Parallelepiped',
          formula: 'V = |a⃗ · (b⃗ × c⃗)|',
          description: 'Volume using scalar triple product'
        }
      ]
    }
  };

  const getAllFormulas = () => {
    return Object.values(formulaCategories).flatMap(category => 
      category.formulas.map(formula => ({ ...formula, category: category.name }))
    );
  };

  const getFilteredFormulas = () => {
    let formulas = selectedTopic === 'all' 
      ? getAllFormulas() 
      : formulaCategories[selectedTopic]?.formulas.map(f => ({ ...f, category: formulaCategories[selectedTopic].name })) || [];

    if (searchTerm) {
      formulas = formulas.filter(formula =>
        formula.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        formula.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        formula.formula.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return formulas;
  };

  const copyFormula = async (formula) => {
    try {
      await navigator.clipboard.writeText(formula);
      setCopiedFormula(formula);
      toast({
        title: "Formula Copied!",
        description: "Formula has been copied to clipboard."
      });
      setTimeout(() => setCopiedFormula(''), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Unable to copy formula to clipboard.",
        variant: "destructive"
      });
    }
  };

  const downloadPDF = () => {
    toast({
      title: "🚧 PDF Download Feature",
      description: "Formula sheet PDF download isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const filteredFormulas = getFilteredFormulas();

  return (
    <>
      <Helmet>
        <title>Formula Sheets - MathSparsh</title>
        <meta name="description" content="Quick access to all important JEE mathematics formulas organized by topics. Copy, search, and download formula sheets for offline study." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Formula Sheets
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Quick access to all important formulas organized by topics for easy revision
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect p-6 rounded-xl mb-8"
          >
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search formulas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="md:w-64">
                <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Topics" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Topics</SelectItem>
                    {Object.entries(formulaCategories).map(([key, category]) => (
                      <SelectItem key={key} value={key}>{category.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={downloadPDF} className="flex items-center space-x-2">
                <Download className="w-4 h-4" />
                <span>Download PDF</span>
              </Button>
            </div>

            <div className="text-gray-300 text-sm">
              Showing {filteredFormulas.length} formulas
              {selectedTopic !== 'all' && ` in ${formulaCategories[selectedTopic]?.name}`}
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-6">
            {filteredFormulas.map((formula, index) => (
              <motion.div
                key={formula.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="question-card p-6 rounded-xl"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <h3 className="text-lg font-semibold text-white">{formula.title}</h3>
                    {formula.important && (
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    )}
                  </div>
                  <span className="px-2 py-1 bg-emerald-500/20 text-emerald-300 rounded text-xs">
                    {formula.category}
                  </span>
                </div>

                <div className="bg-black/30 p-4 rounded-lg mb-4 font-mono text-center">
                  <div className="text-white text-lg break-all">
                    {formula.formula}
                  </div>
                </div>

                <p className="text-gray-300 text-sm mb-4">{formula.description}</p>

                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    {formula.important && (
                      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-300 rounded text-xs">
                        Important
                      </span>
                    )}
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyFormula(formula.formula)}
                    className="flex items-center space-x-1"
                  >
                    {copiedFormula === formula.formula ? (
                      <Check className="w-3 h-3" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                    <span>{copiedFormula === formula.formula ? 'Copied' : 'Copy'}</span>
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredFormulas.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-300 mb-2">No formulas found</h3>
              <p className="text-gray-400">Try adjusting your search or topic filter</p>
            </motion.div>
          )}

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-12 glass-effect p-6 rounded-xl"
          >
            <h2 className="text-xl font-bold text-white mb-4">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div>
                <h3 className="font-semibold text-white mb-2">Study Tips:</h3>
                <ul className="space-y-1">
                  <li>• Practice deriving formulas from first principles</li>
                  <li>• Create your own formula cheat sheet</li>
                  <li>• Use mnemonics for complex formulas</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-white mb-2">Exam Strategy:</h3>
                <ul className="space-y-1">
                  <li>• Memorize starred (important) formulas first</li>
                  <li>• Practice formula applications regularly</li>
                  <li>• Review formulas before mock tests</li>
                </ul>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default FormulaSheetPage;