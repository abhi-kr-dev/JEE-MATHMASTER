import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { BarChart3, TrendingUp, Target, Clock, Award, BookOpen, Calendar, Users, Lock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';

const AnalyticsPage = () => {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState('7days');

  useEffect(() => {
    if (!user) {
      window.location.href = '/login';
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center glass-effect p-12 rounded-xl max-w-md">
          <Lock className="w-16 h-16 text-gray-400 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-white mb-4">Login Required</h2>
          <p className="text-gray-300 mb-6">
            Please login to access your performance analytics and detailed insights.
          </p>
          <div className="space-y-3">
            <Button asChild className="w-full">
              <a href="/login">Login</a>
            </Button>
            <Button asChild variant="outline" className="w-full">
              <a href="/register">Create Account</a>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const overallStats = {
    totalQuestions: 1247,
    correctAnswers: 892,
    accuracy: 71.5,
    timeSpent: 2340,
    streak: 15,
    rank: 342
  };

  const topicPerformance = [
    { topic: 'Algebra', attempted: 245, correct: 189, accuracy: 77.1, timeSpent: 420 },
    { topic: 'Calculus', attempted: 198, correct: 142, accuracy: 71.7, timeSpent: 380 },
    { topic: 'Coordinate Geometry', attempted: 167, correct: 125, accuracy: 74.9, timeSpent: 310 },
    { topic: 'Trigonometry', attempted: 134, correct: 98, accuracy: 73.1, timeSpent: 280 },
    { topic: 'Vectors & 3D', attempted: 89, correct: 67, accuracy: 75.3, timeSpent: 190 }
  ];

  const weeklyProgress = [
    { day: 'Mon', questions: 45, accuracy: 73 },
    { day: 'Tue', questions: 52, accuracy: 69 },
    { day: 'Wed', questions: 38, accuracy: 76 },
    { day: 'Thu', questions: 61, accuracy: 71 },
    { day: 'Fri', questions: 47, accuracy: 74 },
    { day: 'Sat', questions: 55, accuracy: 78 },
    { day: 'Sun', questions: 42, accuracy: 72 }
  ];

  const recentTests = [
    { name: 'JEE Main Mock Test 3', score: 89, maxScore: 120, accuracy: 74, date: '2025-06-24' },
    { name: 'Algebra Quiz', score: 18, maxScore: 20, accuracy: 90, date: '2025-06-23' },
    { name: 'Calculus Practice', score: 14, maxScore: 15, accuracy: 93, date: '2025-06-22' },
    { name: 'Mixed Topics Test', score: 67, maxScore: 80, accuracy: 84, date: '2025-06-21' }
  ];

  const strengthsWeaknesses = {
    strengths: [
      { area: 'Complex Numbers', score: 92 },
      { area: 'Limits', score: 88 },
      { area: 'Coordinate Geometry', score: 85 }
    ],
    weaknesses: [
      { area: 'Differential Equations', score: 58 },
      { area: 'Probability', score: 62 },
      { area: 'Matrices', score: 65 }
    ]
  };

  const getAccuracyColor = (accuracy) => {
    if (accuracy >= 80) return 'text-green-400';
    if (accuracy >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getProgressColor = (accuracy) => {
    if (accuracy >= 80) return 'from-green-500 to-emerald-600';
    if (accuracy >= 70) return 'from-yellow-500 to-orange-600';
    return 'from-red-500 to-pink-600';
  };

  return (
    <>
      <Helmet>
        <title>Performance Analytics - MathSparsh</title>
        <meta name="description" content="Track your JEE mathematics preparation progress with detailed analytics, performance insights, and personalized recommendations." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Performance Analytics
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Track your progress and identify areas for improvement with detailed insights
            </p>
          </motion.div>

          <div className="flex justify-end mb-8">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
                <SelectItem value="90days">Last 3 Months</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <BookOpen className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{overallStats.totalQuestions}</div>
              <div className="text-gray-300">Questions Attempted</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Target className={`w-8 h-8 mx-auto mb-3 ${getAccuracyColor(overallStats.accuracy)}`} />
              <div className={`text-3xl font-bold mb-1 ${getAccuracyColor(overallStats.accuracy)}`}>
                {overallStats.accuracy}%
              </div>
              <div className="text-gray-300">Overall Accuracy</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Clock className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{Math.floor(overallStats.timeSpent / 60)}h</div>
              <div className="text-gray-300">Time Spent</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Award className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">{overallStats.streak}</div>
              <div className="text-gray-300">Day Streak</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <Users className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">#{overallStats.rank}</div>
              <div className="text-gray-300">Global Rank</div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="question-card p-6 rounded-xl text-center"
            >
              <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-white mb-1">+12%</div>
              <div className="text-gray-300">This Week</div>
            </motion.div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-xl font-bold text-white mb-6">Topic-wise Performance</h2>
              <div className="space-y-4">
                {topicPerformance.map((topic, index) => (
                  <div key={index} className="bg-black/20 p-4 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white font-medium">{topic.topic}</span>
                      <span className={`font-bold ${getAccuracyColor(topic.accuracy)}`}>
                        {topic.accuracy}%
                      </span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-400 mb-2">
                      <span>{topic.correct}/{topic.attempted} correct</span>
                      <span>{Math.floor(topic.timeSpent / 60)}h {topic.timeSpent % 60}m</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full bg-gradient-to-r ${getProgressColor(topic.accuracy)}`}
                        style={{ width: `${topic.accuracy}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-xl font-bold text-white mb-6">Weekly Progress</h2>
              <div className="space-y-4">
                {weeklyProgress.map((day, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-white font-medium w-8">{day.day}</span>
                      <div className="flex-1">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-300">{day.questions} questions</span>
                          <span className={getAccuracyColor(day.accuracy)}>{day.accuracy}%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full bg-gradient-to-r ${getProgressColor(day.accuracy)}`}
                            style={{ width: `${(day.questions / 70) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-xl font-bold text-white mb-6">Strengths</h2>
              <div className="space-y-4">
                {strengthsWeaknesses.strengths.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-white">{item.area}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-24 bg-gray-700 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full bg-gradient-to-r from-green-500 to-emerald-600"
                          style={{ width: `${item.score}%` }}
                        ></div>
                      </div>
                      <span className="text-green-400 font-bold w-8">{item.score}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="glass-effect p-6 rounded-xl"
            >
              <h2 className="text-xl font-bold text-white mb-6">Areas for Improvement</h2>
              <div className="space-y-4">
                {strengthsWeaknesses.weaknesses.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-white">{item.area}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-24 bg-gray-700 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full bg-gradient-to-r from-red-500 to-pink-600"
                          style={{ width: `${item.score}%` }}
                        ></div>
                      </div>
                      <span className="text-red-400 font-bold w-8">{item.score}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="glass-effect p-6 rounded-xl"
          >
            <h2 className="text-xl font-bold text-white mb-6">Recent Test Performance</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-600">
                    <th className="text-left text-gray-300 pb-3">Test Name</th>
                    <th className="text-center text-gray-300 pb-3">Score</th>
                    <th className="text-center text-gray-300 pb-3">Accuracy</th>
                    <th className="text-right text-gray-300 pb-3">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTests.map((test, index) => (
                    <tr key={index} className="border-b border-gray-700">
                      <td className="py-3 text-white">{test.name}</td>
                      <td className="py-3 text-center text-white">
                        {test.score}/{test.maxScore}
                      </td>
                      <td className={`py-3 text-center font-bold ${getAccuracyColor(test.accuracy)}`}>
                        {test.accuracy}%
                      </td>
                      <td className="py-3 text-right text-gray-400">
                        {new Date(test.date).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default AnalyticsPage;