import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Upload, Download, Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import QuestionForm from './QuestionForm';

const QuestionManager = () => {
  const [questions, setQuestions] = useState([]);
  const [filteredQuestions, setFilteredQuestions] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTopic, setFilterTopic] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState(null);

  const topics = [
    'Algebra', 'Calculus', 'Coordinate Geometry', 'Trigonometry', 'Vectors & 3D Geometry'
  ];

  const questionTypes = [
    'single-correct', 'multiple-correct', 'numerical', 'paragraph', 'matrix-match'
  ];

  useEffect(() => {
    const mockQuestions = [
      {
        id: 1,
        question: "If the roots of the equation x² - 3x + k = 0 are real and distinct, then the range of k is:",
        topic: 'Algebra',
        subtopic: 'Quadratic Equations',
        type: 'single-correct',
        level: 'basic',
        options: ['k < 9/4', 'k > 9/4', 'k ≤ 9/4', 'k ≥ 9/4'],
        correctAnswer: [0],
        solution: "For real and distinct roots, discriminant > 0. So 9 - 4k > 0, which gives k < 9/4.",
        createdAt: '2025-06-20'
      },
      {
        id: 2,
        question: "Find the derivative of f(x) = sin(x²) with respect to x:",
        topic: 'Calculus',
        subtopic: 'Derivatives',
        type: 'single-correct',
        level: 'intermediate',
        options: ['2x cos(x²)', 'cos(x²)', '2x sin(x²)', 'sin(2x)'],
        correctAnswer: [0],
        solution: "Using chain rule: d/dx[sin(x²)] = cos(x²) × d/dx[x²] = cos(x²) × 2x = 2x cos(x²)",
        createdAt: '2025-06-21'
      }
    ];
    setQuestions(mockQuestions);
    setFilteredQuestions(mockQuestions);
  }, []);

  useEffect(() => {
    let filtered = questions.filter(q => {
      const matchesSearch = q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           q.subtopic.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTopic = filterTopic === 'all' || q.topic === filterTopic;
      const matchesType = filterType === 'all' || q.type === filterType;

      return matchesSearch && matchesTopic && matchesType;
    });

    setFilteredQuestions(filtered);
  }, [searchTerm, filterTopic, filterType, questions]);

  const handleAddQuestion = () => {
    setEditingQuestion(null);
    setShowForm(true);
  };

  const handleEditQuestion = (question) => {
    setEditingQuestion(question);
    setShowForm(true);
  };

  const handleDeleteQuestion = (questionId) => {
    setQuestions(prev => prev.filter(q => q.id !== questionId));
    toast({
      title: "Question Deleted",
      description: "The question has been successfully deleted.",
    });
  };

  const handleSaveQuestion = (questionData) => {
    if (editingQuestion) {
      setQuestions(prev => prev.map(q => 
        q.id === editingQuestion.id ? { ...questionData, id: editingQuestion.id } : q
      ));
      toast({
        title: "Question Updated",
        description: "The question has been successfully updated.",
      });
    } else {
      const newQuestion = {
        ...questionData,
        id: Math.max(...questions.map(q => q.id), 0) + 1,
        createdAt: new Date().toISOString().split('T')[0]
      };
      setQuestions(prev => [...prev, newQuestion]);
      toast({
        title: "Question Added",
        description: "The question has been successfully added.",
      });
    }
    setShowForm(false);
    setEditingQuestion(null);
  };

  const handleBulkUpload = () => {
    toast({
      title: "🚧 Bulk Upload Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleExport = () => {
    toast({
      title: "🚧 Export Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  if (showForm) {
    return (
      <QuestionForm
        question={editingQuestion}
        onSave={handleSaveQuestion}
        onCancel={() => {
          setShowForm(false);
          setEditingQuestion(null);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-white">Question Management</h2>
        <div className="flex flex-wrap gap-2">
          <Button onClick={handleBulkUpload} variant="outline" size="sm">
            <Upload className="w-4 h-4 mr-2" />
            Bulk Upload
          </Button>
          <Button onClick={handleExport} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={handleAddQuestion}>
            <Plus className="w-4 h-4 mr-2" />
            Add Question
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-4 p-4 bg-black/20 rounded-lg">
        <div>
          <Label className="text-white mb-2 block">Search</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search questions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <Label className="text-white mb-2 block">Topic</Label>
          <Select value={filterTopic} onValueChange={setFilterTopic}>
            <SelectTrigger>
              <SelectValue placeholder="All Topics" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Topics</SelectItem>
              {topics.map((topic) => (
                <SelectItem key={topic} value={topic}>{topic}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-white mb-2 block">Type</Label>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger>
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {questionTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-end">
          <div className="text-sm text-gray-300">
            {filteredQuestions.length} of {questions.length} questions
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filteredQuestions.map((question, index) => (
          <motion.div
            key={question.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-black/20 p-6 rounded-lg border border-gray-600"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-4 mb-2">
                  <span className="text-sm bg-blue-500/20 text-blue-300 px-2 py-1 rounded">
                    {question.topic}
                  </span>
                  <span className="text-sm bg-purple-500/20 text-purple-300 px-2 py-1 rounded">
                    {question.type.replace('-', ' ')}
                  </span>
                  <span className="text-sm bg-green-500/20 text-green-300 px-2 py-1 rounded">
                    {question.level}
                  </span>
                </div>
                <h3 className="text-white font-medium mb-2">
                  Question {question.id}: {question.question.substring(0, 100)}...
                </h3>
                <p className="text-gray-400 text-sm">
                  {question.subtopic} • Created: {question.createdAt}
                </p>
              </div>
              <div className="flex space-x-2 ml-4">
                <Button
                  onClick={() => handleEditQuestion(question)}
                  variant="outline"
                  size="sm"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button
                  onClick={() => handleDeleteQuestion(question.id)}
                  variant="outline"
                  size="sm"
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {question.options && (
              <div className="grid md:grid-cols-2 gap-2 text-sm">
                {question.options.slice(0, 2).map((option, optIndex) => (
                  <div key={optIndex} className="text-gray-300">
                    ({String.fromCharCode(65 + optIndex)}) {option.substring(0, 50)}...
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {filteredQuestions.length === 0 && (
        <div className="text-center py-12">
          <Filter className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-300 mb-2">No questions found</h3>
          <p className="text-gray-400">Try adjusting your search criteria or add new questions.</p>
        </div>
      )}
    </div>
  );
};

export default QuestionManager;