import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, BookOpen, Crown, TrendingUp, Target, Clock, Award, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const AnalyticsDashboard = () => {
  const [timeRange, setTimeRange] = useState('7days');

  const overallStats = [
    { label: 'Total Users', value: '2,847', change: '+12%', icon: Users, color: 'text-blue-400' },
    { label: 'Premium Users', value: '892', change: '+18%', icon: Crown, color: 'text-yellow-400' },
    { label: 'Questions Attempted', value: '45,672', change: '+25%', icon: BookOpen, color: 'text-emerald-400' },
    { label: 'Average Accuracy', value: '78%', change: '+3%', icon: Target, color: 'text-purple-400' }
  ];

  const topicStats = [
    { topic: 'Algebra', attempts: 12456, accuracy: 76, avgTime: 3.2 },
    { topic: 'Calculus', attempts: 10892, accuracy: 72, avgTime: 4.1 },
    { topic: 'Coordinate Geometry', attempts: 8934, accuracy: 79, avgTime: 3.8 },
    { topic: 'Trigonometry', attempts: 7623, accuracy: 81, avgTime: 2.9 },
    { topic: 'Vectors & 3D', attempts: 5767, accuracy: 74, avgTime: 4.5 }
  ];

  const recentActivity = [
    { action: 'New user registration', user: 'Arjun Sharma', time: '2 minutes ago' },
    { action: 'Premium upgrade', user: 'Priya Patel', time: '15 minutes ago' },
    { action: 'Mock test completed', user: 'Rahul Kumar', time: '32 minutes ago' },
    { action: 'Question added', user: 'Admin', time: '1 hour ago' },
    { action: 'Bulk upload completed', user: 'Admin', time: '2 hours ago' }
  ];

  const userGrowth = [
    { month: 'Jan', users: 1200, premium: 180 },
    { month: 'Feb', users: 1450, premium: 245 },
    { month: 'Mar', users: 1780, premium: 320 },
    { month: 'Apr', users: 2100, premium: 456 },
    { month: 'May', users: 2450, premium: 623 },
    { month: 'Jun', users: 2847, premium: 892 }
  ];

  const getAccuracyColor = (accuracy) => {
    if (accuracy >= 80) return 'text-green-400';
    if (accuracy >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  const handleExportReport = () => {
    toast({
      title: "🚧 Export Report Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-white">Analytics Dashboard</h2>
        <div className="flex items-center space-x-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="90days">Last 3 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExportReport} variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {overallStats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-black/20 p-6 rounded-lg border border-gray-600"
          >
            <div className="flex items-center justify-between mb-4">
              <stat.icon className={`w-8 h-8 ${stat.color}`} />
              <span className="text-green-400 text-sm font-medium">{stat.change}</span>
            </div>
            <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
            <div className="text-gray-400 text-sm">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-black/20 p-6 rounded-lg border border-gray-600"
        >
          <h3 className="text-xl font-bold text-white mb-6">Topic Performance</h3>
          <div className="space-y-4">
            {topicStats.map((topic, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-black/20 rounded-lg">
                <div>
                  <h4 className="text-white font-medium">{topic.topic}</h4>
                  <p className="text-gray-400 text-sm">{topic.attempts} attempts</p>
                </div>
                <div className="text-right">
                  <div className={`font-bold ${getAccuracyColor(topic.accuracy)}`}>
                    {topic.accuracy}%
                  </div>
                  <div className="text-gray-400 text-sm">{topic.avgTime}m avg</div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-black/20 p-6 rounded-lg border border-gray-600"
        >
          <h3 className="text-xl font-bold text-white mb-6">Recent Activity</h3>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-black/20 rounded-lg">
                <div className="w-2 h-2 bg-emerald-400 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="text-white text-sm">{activity.action}</p>
                  <p className="text-gray-400 text-xs">{activity.user} • {activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-black/20 p-6 rounded-lg border border-gray-600"
      >
        <h3 className="text-xl font-bold text-white mb-6">User Growth Trend</h3>
        <div className="grid md:grid-cols-6 gap-4">
          {userGrowth.map((data, index) => (
            <div key={index} className="text-center">
              <div className="text-2xl font-bold text-white mb-1">{data.users}</div>
              <div className="text-yellow-400 text-sm mb-1">{data.premium} premium</div>
              <div className="text-gray-400 text-xs">{data.month}</div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-black/20 p-6 rounded-lg border border-gray-600"
      >
        <h3 className="text-xl font-bold text-white mb-6">Key Insights</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-emerald-400 font-medium mb-2">Top Performing Areas</h4>
            <ul className="space-y-1 text-gray-300 text-sm">
              <li>• Trigonometry has the highest accuracy (81%)</li>
              <li>• Coordinate Geometry shows consistent improvement</li>
              <li>• Premium users score 15% higher on average</li>
            </ul>
          </div>
          <div>
            <h4 className="text-yellow-400 font-medium mb-2">Areas for Improvement</h4>
            <ul className="space-y-1 text-gray-300 text-sm">
              <li>• Calculus needs more practice resources</li>
              <li>• Vectors & 3D has longest average solve time</li>
              <li>• Free users need more engagement features</li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AnalyticsDashboard;