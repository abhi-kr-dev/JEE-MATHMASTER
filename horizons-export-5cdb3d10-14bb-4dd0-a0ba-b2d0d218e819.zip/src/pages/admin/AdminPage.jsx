import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Plus, Edit, Trash2, Upload, Download, Settings, Users, BookOpen, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthenticationContext.jsx';
import { toast } from '@/components/ui/use-toast';
import QuestionManager from './QuestionManager';
import UserManager from './UserManager';
import AnalyticsDashboard from './AnalyticsDashboard';

const AdminPage = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('questions');

  if (!user || user.email !== 'admin@mathsparsh.com') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Access Denied</h2>
          <p className="text-gray-300 mb-4">You don't have permission to access the admin panel.</p>
          <Button onClick={() => window.location.href = '/'}>
            Go to Home
          </Button>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'questions', label: 'Question Management', icon: BookOpen },
    { id: 'users', label: 'User Management', icon: Users },
    { id: 'analytics', label: 'Analytics Dashboard', icon: BarChart3 }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'questions':
        return <QuestionManager />;
      case 'users':
        return <UserManager />;
      case 'analytics':
        return <AnalyticsDashboard />;
      default:
        return <QuestionManager />;
    }
  };

  return (
    <>
      <Helmet>
        <title>Admin Panel - MathSparsh</title>
        <meta name="description" content="MathSparsh admin panel for managing questions, users, and analytics." />
      </Helmet>

      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Settings className="w-8 h-8 text-emerald-400" />
              <h1 className="text-4xl md:text-5xl font-bold gradient-text">
                Admin Panel
              </h1>
            </div>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Manage questions, users, and monitor platform analytics
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect rounded-xl overflow-hidden"
          >
            <div className="border-b border-white/10">
              <nav className="flex space-x-8 px-6">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                      activeTab === tab.id
                        ? 'border-emerald-400 text-emerald-400'
                        : 'border-transparent text-gray-400 hover:text-white'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>

            <div className="p-6">
              {renderTabContent()}
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default AdminPage;