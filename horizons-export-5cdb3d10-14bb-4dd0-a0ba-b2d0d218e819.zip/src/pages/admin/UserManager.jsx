import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Crown, Users, UserCheck, UserX, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const UserManager = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    const mockUsers = [
      {
        id: 1,
        name: 'Arjun Sharma',
        email: 'arjun@example.com',
        isPremium: true,
        joinedDate: '2025-01-15',
        lastActive: '2025-06-24',
        questionsAttempted: 1247,
        accuracy: 78,
        status: 'active'
      },
      {
        id: 2,
        name: 'Priya Patel',
        email: 'priya@example.com',
        isPremium: false,
        joinedDate: '2025-02-20',
        lastActive: '2025-06-23',
        questionsAttempted: 892,
        accuracy: 82,
        status: 'active'
      },
      {
        id: 3,
        name: 'Rahul Kumar',
        email: 'rahul@example.com',
        isPremium: true,
        joinedDate: '2025-01-10',
        lastActive: '2025-06-22',
        questionsAttempted: 1456,
        accuracy: 75,
        status: 'active'
      },
      {
        id: 4,
        name: 'Sneha Gupta',
        email: 'sneha@example.com',
        isPremium: false,
        joinedDate: '2025-03-05',
        lastActive: '2025-06-10',
        questionsAttempted: 567,
        accuracy: 85,
        status: 'inactive'
      }
    ];
    setUsers(mockUsers);
    setFilteredUsers(mockUsers);
  }, []);

  useEffect(() => {
    let filtered = users.filter(user => {
      const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           user.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = filterStatus === 'all' || 
                           (filterStatus === 'premium' && user.isPremium) ||
                           (filterStatus === 'free' && !user.isPremium) ||
                           (filterStatus === 'active' && user.status === 'active') ||
                           (filterStatus === 'inactive' && user.status === 'inactive');

      return matchesSearch && matchesStatus;
    });

    setFilteredUsers(filtered);
  }, [searchTerm, filterStatus, users]);

  const handleTogglePremium = (userId) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isPremium: !user.isPremium } : user
    ));
    toast({
      title: "User Updated",
      description: "User premium status has been updated successfully.",
    });
  };

  const handleToggleStatus = (userId) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { 
        ...user, 
        status: user.status === 'active' ? 'inactive' : 'active' 
      } : user
    ));
    toast({
      title: "User Status Updated",
      description: "User status has been updated successfully.",
    });
  };

  const handleSendEmail = (userEmail) => {
    toast({
      title: "🚧 Email Feature",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const getStatusColor = (status) => {
    return status === 'active' ? 'text-green-400' : 'text-red-400';
  };

  const getAccuracyColor = (accuracy) => {
    if (accuracy >= 80) return 'text-green-400';
    if (accuracy >= 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-white">User Management</h2>
        <div className="text-sm text-gray-300">
          Total Users: {users.length} | Premium: {users.filter(u => u.isPremium).length}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4 p-4 bg-black/20 rounded-lg">
        <div>
          <Label className="text-white mb-2 block">Search Users</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <Label className="text-white mb-2 block">Filter by Status</Label>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger>
              <SelectValue placeholder="All Users" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              <SelectItem value="premium">Premium Users</SelectItem>
              <SelectItem value="free">Free Users</SelectItem>
              <SelectItem value="active">Active Users</SelectItem>
              <SelectItem value="inactive">Inactive Users</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-end">
          <div className="text-sm text-gray-300">
            Showing {filteredUsers.length} of {users.length} users
          </div>
        </div>
      </div>

      <div className="grid gap-4">
        {filteredUsers.map((user, index) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-black/20 p-6 rounded-lg border border-gray-600"
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-white">{user.name}</h3>
                  {user.isPremium && <Crown className="w-5 h-5 text-yellow-400" />}
                  <span className={`text-sm font-medium ${getStatusColor(user.status)}`}>
                    {user.status}
                  </span>
                </div>
                <p className="text-gray-400 mb-3">{user.email}</p>
                
                <div className="grid md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Joined:</span>
                    <div className="text-white">{new Date(user.joinedDate).toLocaleDateString()}</div>
                  </div>
                  <div>
                    <span className="text-gray-400">Last Active:</span>
                    <div className="text-white">{new Date(user.lastActive).toLocaleDateString()}</div>
                  </div>
                  <div>
                    <span className="text-gray-400">Questions:</span>
                    <div className="text-white">{user.questionsAttempted}</div>
                  </div>
                  <div>
                    <span className="text-gray-400">Accuracy:</span>
                    <div className={getAccuracyColor(user.accuracy)}>{user.accuracy}%</div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() => handleTogglePremium(user.id)}
                  variant={user.isPremium ? "default" : "outline"}
                  size="sm"
                >
                  <Crown className="w-4 h-4 mr-1" />
                  {user.isPremium ? 'Remove Premium' : 'Make Premium'}
                </Button>
                
                <Button
                  onClick={() => handleToggleStatus(user.id)}
                  variant="outline"
                  size="sm"
                >
                  {user.status === 'active' ? (
                    <>
                      <UserX className="w-4 h-4 mr-1" />
                      Deactivate
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-4 h-4 mr-1" />
                      Activate
                    </>
                  )}
                </Button>
                
                <Button
                  onClick={() => handleSendEmail(user.email)}
                  variant="outline"
                  size="sm"
                >
                  <Mail className="w-4 h-4 mr-1" />
                  Email
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-300 mb-2">No users found</h3>
          <p className="text-gray-400">Try adjusting your search criteria.</p>
        </div>
      )}
    </div>
  );
};

export default UserManager;