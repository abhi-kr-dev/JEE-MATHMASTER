import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Save, X, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const QuestionForm = ({ question, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    question: '',
    topic: '',
    subtopic: '',
    type: 'single-correct',
    level: 'basic',
    options: ['', '', '', ''],
    correctAnswer: [],
    answer: '',
    columnA: ['', '', '', ''],
    columnB: ['', '', '', ''],
    correctMatches: [],
    solution: ''
  });

  const topics = {
    'Algebra': ['Quadratic Equations', 'Complex Numbers', 'Sequences & Series', 'Permutations & Combinations'],
    'Calculus': ['Limits', 'Derivatives', 'Integrals', 'Differential Equations'],
    'Coordinate Geometry': ['Straight Lines', 'Circles', 'Parabola', 'Ellipse', 'Hyperbola'],
    'Trigonometry': ['Basic Trigonometry', 'Inverse Trigonometry', 'Trigonometric Equations'],
    'Vectors & 3D Geometry': ['Vector Algebra', 'Scalar Triple Product', 'Vector Triple Product', '3D Lines & Planes']
  };

  const questionTypes = [
    { value: 'single-correct', label: 'Single Correct Answer' },
    { value: 'multiple-correct', label: 'Multiple Correct Answer' },
    { value: 'numerical', label: 'Numerical Type' },
    { value: 'paragraph', label: 'Paragraph Type' },
    { value: 'matrix-match', label: 'Matrix Match' }
  ];

  const levels = [
    { value: 'basic', label: 'Basic' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  useEffect(() => {
    if (question) {
      setFormData({
        question: question.question || '',
        topic: question.topic || '',
        subtopic: question.subtopic || '',
        type: question.type || 'single-correct',
        level: question.level || 'basic',
        options: question.options || ['', '', '', ''],
        correctAnswer: question.correctAnswer || [],
        answer: question.answer || '',
        columnA: question.columnA || ['', '', '', ''],
        columnB: question.columnB || ['', '', '', ''],
        correctMatches: question.correctMatches || [],
        solution: question.solution || ''
      });
    }
  }, [question]);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleOptionChange = (index, value) => {
    const newOptions = [...formData.options];
    newOptions[index] = value;
    setFormData(prev => ({
      ...prev,
      options: newOptions
    }));
  };

  const handleCorrectAnswerToggle = (index) => {
    if (formData.type === 'single-correct') {
      setFormData(prev => ({
        ...prev,
        correctAnswer: [index]
      }));
    } else if (formData.type === 'multiple-correct') {
      const newCorrectAnswer = [...formData.correctAnswer];
      if (newCorrectAnswer.includes(index)) {
        newCorrectAnswer.splice(newCorrectAnswer.indexOf(index), 1);
      } else {
        newCorrectAnswer.push(index);
      }
      setFormData(prev => ({
        ...prev,
        correctAnswer: newCorrectAnswer
      }));
    }
  };

  const handleColumnChange = (column, index, value) => {
    const newColumn = [...formData[column]];
    newColumn[index] = value;
    setFormData(prev => ({
      ...prev,
      [column]: newColumn
    }));
  };

  const addOption = () => {
    setFormData(prev => ({
      ...prev,
      options: [...prev.options, '']
    }));
  };

  const removeOption = (index) => {
    if (formData.options.length > 2) {
      const newOptions = formData.options.filter((_, i) => i !== index);
      const newCorrectAnswer = formData.correctAnswer.filter(i => i !== index).map(i => i > index ? i - 1 : i);
      setFormData(prev => ({
        ...prev,
        options: newOptions,
        correctAnswer: newCorrectAnswer
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const renderQuestionTypeFields = () => {
    switch (formData.type) {
      case 'single-correct':
      case 'multiple-correct':
        return (
          <div className="space-y-4">
            <Label className="text-white">Options</Label>
            {formData.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <input
                  type={formData.type === 'single-correct' ? 'radio' : 'checkbox'}
                  name="correctAnswer"
                  checked={formData.correctAnswer.includes(index)}
                  onChange={() => handleCorrectAnswerToggle(index)}
                  className="w-4 h-4"
                />
                <Input
                  value={option}
                  onChange={(e) => handleOptionChange(index, e.target.value)}
                  placeholder={`Option ${String.fromCharCode(65 + index)}`}
                  className="flex-1"
                />
                {formData.options.length > 2 && (
                  <Button
                    type="button"
                    onClick={() => removeOption(index)}
                    variant="outline"
                    size="sm"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button type="button" onClick={addOption} variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Option
            </Button>
          </div>
        );

      case 'numerical':
        return (
          <div>
            <Label htmlFor="answer" className="text-white mb-2 block">Correct Answer</Label>
            <Input
              id="answer"
              type="number"
              value={formData.answer}
              onChange={(e) => handleInputChange('answer', e.target.value)}
              placeholder="Enter the numerical answer"
            />
          </div>
        );

      case 'matrix-match':
        return (
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label className="text-white mb-2 block">Column A</Label>
              {formData.columnA.map((item, index) => (
                <Input
                  key={index}
                  value={item}
                  onChange={(e) => handleColumnChange('columnA', index, e.target.value)}
                  placeholder={`Item ${index + 1}`}
                  className="mb-2"
                />
              ))}
            </div>
            <div>
              <Label className="text-white mb-2 block">Column B</Label>
              {formData.columnB.map((item, index) => (
                <Input
                  key={index}
                  value={item}
                  onChange={(e) => handleColumnChange('columnB', index, e.target.value)}
                  placeholder={`Item ${String.fromCharCode(65 + index)}`}
                  className="mb-2"
                />
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">
          {question ? 'Edit Question' : 'Add New Question'}
        </h2>
        <Button onClick={onCancel} variant="outline">
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="question" className="text-white mb-2 block">Question</Label>
          <textarea
            id="question"
            value={formData.question}
            onChange={(e) => handleInputChange('question', e.target.value)}
            placeholder="Enter the question text"
            className="w-full p-3 bg-black/20 border border-gray-600 rounded-lg text-white placeholder-gray-400 min-h-[100px]"
            required
          />
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="topic" className="text-white mb-2 block">Topic</Label>
            <Select value={formData.topic} onValueChange={(value) => handleInputChange('topic', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select topic" />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(topics).map((topic) => (
                  <SelectItem key={topic} value={topic}>{topic}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="subtopic" className="text-white mb-2 block">Subtopic</Label>
            <Select 
              value={formData.subtopic} 
              onValueChange={(value) => handleInputChange('subtopic', value)}
              disabled={!formData.topic}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select subtopic" />
              </SelectTrigger>
              <SelectContent>
                {formData.topic && topics[formData.topic]?.map((subtopic) => (
                  <SelectItem key={subtopic} value={subtopic}>{subtopic}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="level" className="text-white mb-2 block">Difficulty Level</Label>
            <Select value={formData.level} onValueChange={(value) => handleInputChange('level', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Select level" />
              </SelectTrigger>
              <SelectContent>
                {levels.map((level) => (
                  <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="type" className="text-white mb-2 block">Question Type</Label>
          <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              {questionTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {renderQuestionTypeFields()}

        <div>
          <Label htmlFor="solution" className="text-white mb-2 block">Solution/Explanation</Label>
          <textarea
            id="solution"
            value={formData.solution}
            onChange={(e) => handleInputChange('solution', e.target.value)}
            placeholder="Enter the detailed solution and explanation"
            className="w-full p-3 bg-black/20 border border-gray-600 rounded-lg text-white placeholder-gray-400 min-h-[100px]"
            required
          />
        </div>

        <div className="flex justify-end space-x-4">
          <Button type="button" onClick={onCancel} variant="outline">
            Cancel
          </Button>
          <Button type="submit">
            <Save className="w-4 h-4 mr-2" />
            {question ? 'Update Question' : 'Save Question'}
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default QuestionForm;