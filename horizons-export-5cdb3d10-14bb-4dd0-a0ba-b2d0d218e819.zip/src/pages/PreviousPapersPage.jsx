import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Download, PlayCircle, Filter, Search, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const PreviousPapersPage = () => {
  const [filterYear, setFilterYear] = useState('all');
  const [filterExam, setFilterExam] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const papers = [
    { year: 2025, exam: 'JEE Advanced', paper: 1, qpLink: '#', solLink: '#' },
    { year: 2025, exam: 'JEE Advanced', paper: 2, qpLink: '#', solLink: '#' },
    { year: 2025, exam: 'JEE Main', session: 'April - Shift 1', qpLink: '#', solLink: '#' },
    { year: 2025, exam: 'JEE Main', session: 'April - Shift 2', qpLink: '#', solLink: '#' },
    { year: 2024, exam: 'JEE Advanced', paper: 1, qpLink: '#', solLink: '#' },
    { year: 2024, exam: 'JEE Advanced', paper: 2, qpLink: '#', solLink: '#' },
    { year: 2024, exam: 'JEE Main', session: 'Jan - Shift 1', qpLink: '#', solLink: '#' },
    { year: 2023, exam: 'JEE Advanced', paper: 1, qpLink: '#', solLink: '#' },
    { year: 2023, exam: 'JEE Advanced', paper: 2, qpLink: '#', solLink: '#' },
    { year: 2023, exam: 'JEE Main', session: 'April - Shift 1', qpLink: '#', solLink: '#' },
  ];

  const handleAction = (action) => {
    toast({
      title: `🚧 ${action} Feature`,
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const getExamColor = (exam) => {
    if (exam === 'JEE Advanced') return 'bg-purple-500/20 text-purple-300';
    return 'bg-blue-500/20 text-blue-300';
  };
  
  const filteredPapers = papers.filter(p => {
    const yearMatch = filterYear === 'all' || p.year === parseInt(filterYear);
    const examMatch = filterExam === 'all' || p.exam === filterExam;
    const searchMatch = searchTerm === '' || 
      p.exam.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (p.session && p.session.toLowerCase().includes(searchTerm.toLowerCase()));
    return yearMatch && examMatch && searchMatch;
  });

  const years = [...new Set(papers.map(p => p.year))];

  return (
    <>
      <Helmet>
        <title>Previous Year Papers - MathSparsh</title>
        <meta name="description" content="Download and practice with official JEE Main & Advanced previous year question papers. Analyze patterns and prepare effectively." />
      </Helmet>
      <div className="min-h-screen py-8 px-4">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
              Previous Year Papers
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Practice with official papers to master the exam pattern and difficulty level
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="glass-effect p-6 rounded-xl mb-8"
          >
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search papers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterYear} onValueChange={setFilterYear}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by Year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  {years.map(year => <SelectItem key={year} value={String(year)}>{year}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterExam} onValueChange={setFilterExam}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by Exam" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Exams</SelectItem>
                  <SelectItem value="JEE Main">JEE Main</SelectItem>
                  <SelectItem value="JEE Advanced">JEE Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-6">
            {filteredPapers.map((paper, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="question-card p-6 rounded-xl"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-white">{paper.exam} {paper.year}</h3>
                    <p className="text-gray-300">
                      {paper.paper ? `Paper ${paper.paper}` : paper.session}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${getExamColor(paper.exam)}`}>
                    {paper.exam}
                  </span>
                </div>

                <div className="border-t border-b border-white/10 my-4 py-4">
                  <div className="flex justify-around">
                    <Button variant="ghost" className="flex flex-col h-auto p-2" onClick={() => handleAction('Download Questions')}>
                      <Download className="w-6 h-6 text-emerald-400" />
                      <span className="text-xs mt-1 text-gray-300">Questions</span>
                    </Button>
                    <Button variant="ghost" className="flex flex-col h-auto p-2" onClick={() => handleAction('Download Solutions')}>
                      <Download className="w-6 h-6 text-blue-400" />
                      <span className="text-xs mt-1 text-gray-300">Solutions</span>
                    </Button>
                  </div>
                </div>

                <Button className="w-full" onClick={() => handleAction('Attempt as Mock Test')}>
                  <PlayCircle className="w-5 h-5 mr-2" />
                  Attempt as Mock Test
                </Button>
              </motion.div>
            ))}
             {filteredPapers.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12 lg:col-span-2"
              >
                <Filter className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-300 mb-2">No Papers Found</h3>
                <p className="text-gray-400">Try adjusting your filters.</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default PreviousPapersPage;