
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Eye } from 'lucide-react';
import { Input } from '@/components/ui/input';

const QuestionDisplay = ({ 
  question, 
  userAnswer, 
  showSolution, 
  onAnswerSelect, 
  onNumericalAnswer, 
  onMatrixMatch,
  isCorrectAnswer,
  getAnswerStatus 
}) => {
  const answerStatus = getAnswerStatus(question, userAnswer);

  const renderMatrixMatch = () => (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-white font-medium mb-3">Column A</h4>
          <div className="space-y-2">
            {question.columnA.map((item, aIndex) => (
              <div key={aIndex} className="bg-black/20 p-3 rounded-lg">
                <span className="text-gray-300">({aIndex + 1}) {item}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h4 className="text-white font-medium mb-3">Column B</h4>
          <div className="space-y-2">
            {question.columnB.map((item, bIndex) => (
              <button
                key={bIndex}
                onClick={() => {
                  const selectedA = (userAnswer || []).length;
                  if (selectedA < question.columnA.length) {
                    onMatrixMatch(question.id, selectedA, bIndex);
                  }
                }}
                className="w-full bg-black/20 p-3 rounded-lg text-left hover:bg-black/30 transition-colors"
              >
                <span className="text-gray-300">({String.fromCharCode(65 + bIndex)}) {item}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
      {userAnswer && userAnswer.length > 0 && (
        <div className="bg-blue-500/10 p-4 rounded-lg">
          <h5 className="text-blue-300 font-medium mb-2">Your Matches:</h5>
          <div className="space-y-1">
            {userAnswer.map((match, index) => (
              <div key={index} className="text-blue-200 text-sm">
                ({match[0] + 1}) {question.columnA[match[0]]} → ({String.fromCharCode(65 + match[1])}) {question.columnB[match[1]]}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderNumerical = () => (
    <div className="space-y-4">
      <Input
        type="number"
        placeholder="Enter your answer"
        onChange={(e) => onNumericalAnswer(question.id, e.target.value)}
        className="max-w-xs"
      />
      {showSolution && userAnswer !== undefined && (
        <div className="text-white">
          Your answer: <span className={answerStatus === 'correct' ? 'text-green-400' : 'text-red-400'}>{userAnswer}</span>
          {answerStatus === 'incorrect' && (
            <div className="text-green-400 mt-1">Correct answer: {question.answer}</div>
          )}
        </div>
      )}
    </div>
  );

  const renderOptions = () => (
    <div className="space-y-3">
      {question.options.map((option, optIndex) => {
        const isSelected = userAnswer && userAnswer.includes(optIndex);
        const isCorrect = question.correctAnswer.includes(optIndex);
        const showResult = showSolution && userAnswer;
        
        return (
          <motion.button
            key={optIndex}
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={() => onAnswerSelect(question.id, optIndex, question.type === 'multiple-correct')}
            className={`w-full p-4 text-left rounded-lg border transition-all ${
              showResult
                ? isCorrect
                  ? 'answer-correct'
                  : isSelected
                  ? 'answer-incorrect'
                  : 'bg-black/20 border-gray-600 text-gray-300'
                : isSelected
                ? 'selected-answer'
                : 'bg-black/20 border-gray-600 hover:border-gray-500 text-gray-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <span>
                <span className="text-gray-400 mr-3">
                  ({String.fromCharCode(65 + optIndex)})
                </span>
                {option}
              </span>
              {showResult && isCorrect && <CheckCircle className="w-5 h-5 text-green-400" />}
              {showResult && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-400" />}
            </div>
          </motion.button>
        );
      })}
    </div>
  );

  const renderQuestionContent = () => {
    switch (question.type) {
      case 'matrix-match':
        return renderMatrixMatch();
      case 'numerical':
        return renderNumerical();
      default:
        return renderOptions();
    }
  };

  return (
    <div>
      {renderQuestionContent()}
      
      {showSolution && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="mt-6 p-4 bg-blue-500/10 rounded-lg border border-blue-500/30"
        >
          <div className="flex items-center space-x-2 mb-2">
            <Eye className="w-4 h-4 text-blue-400" />
            <h4 className="text-blue-300 font-medium">Solution:</h4>
          </div>
          <p className="text-blue-200 text-sm">{question.solution}</p>
        </motion.div>
      )}
    </div>
  );
};

export default QuestionDisplay;
