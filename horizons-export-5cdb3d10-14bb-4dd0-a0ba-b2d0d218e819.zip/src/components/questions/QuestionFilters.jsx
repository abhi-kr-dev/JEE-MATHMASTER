
import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const QuestionFilters = ({
  searchTerm,
  setSearchTerm,
  selectedTopic,
  setSelectedTopic,
  selectedSubtopic,
  setSelectedSubtopic,
  selectedLevel,
  setSelectedLevel,
  selectedType,
  setSelectedType,
  topics,
  levels,
  questionTypes
}) => {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-4 mb-6">
      <div className="lg:col-span-2">
        <Label htmlFor="search" className="text-white mb-2 block">Search Questions</Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            id="search"
            placeholder="Search by topic or question..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div>
        <Label className="text-white mb-2 block">Topic</Label>
        <Select value={selectedTopic} onValueChange={setSelectedTopic}>
          <SelectTrigger>
            <SelectValue placeholder="All Topics" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Topics</SelectItem>
            {Object.entries(topics).map(([key, topic]) => (
              <SelectItem key={key} value={key}>{topic.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-white mb-2 block">Subtopic</Label>
        <Select value={selectedSubtopic} onValueChange={setSelectedSubtopic}>
          <SelectTrigger>
            <SelectValue placeholder="All Subtopics" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Subtopics</SelectItem>
            {selectedTopic !== 'all' && topics[selectedTopic] && 
              topics[selectedTopic].subtopics.map((subtopic) => (
                <SelectItem key={subtopic} value={subtopic}>{subtopic}</SelectItem>
              ))
            }
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-white mb-2 block">Level</Label>
        <Select value={selectedLevel} onValueChange={setSelectedLevel}>
          <SelectTrigger>
            <SelectValue placeholder="All Levels" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            {levels.map((level) => (
              <SelectItem key={level.value} value={level.value}>{level.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-white mb-2 block">Question Type</Label>
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger>
            <SelectValue placeholder="All Types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {questionTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default QuestionFilters;
