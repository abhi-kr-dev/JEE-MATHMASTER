
import React from 'react';
import { motion } from 'framer-motion';
import { Filter, CheckCircle, XCircle } from 'lucide-react';
import QuestionDisplay from './QuestionDisplay';

const QuestionCard = ({
  question,
  index,
  userAnswer,
  showSolution,
  answerStatus,
  onAnswerSelect,
  onNumericalAnswer,
  onMatrixMatch,
  isCorrectAnswer,
  getAnswerStatus,
  getQuestionTypeIcon,
  getLevelColor,
  questionTypes,
  levels
}) => {
  const TypeIcon = getQuestionTypeIcon(question.type);

  return (
    <motion.div
      key={question.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className={`question-card p-6 rounded-xl ${
        answerStatus === 'correct' ? 'border-green-500/50 bg-green-500/5' :
        answerStatus === 'incorrect' ? 'border-red-500/50 bg-red-500/5' : ''
      }`}
    >
      <div className="flex flex-wrap items-center gap-4 mb-4">
        <div className="flex items-center space-x-2">
          <TypeIcon className="w-5 h-5 text-blue-400" />
          <span className="text-sm text-gray-300">
            {questionTypes.find(qt => qt.value === question.type)?.label}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-gray-300">{question.subtopic}</span>
        </div>
        <div className={`text-sm font-medium ${getLevelColor(question.level)}`}>
          {levels.find(l => l.value === question.level)?.label}
        </div>
        {answerStatus && (
          <div className="flex items-center space-x-1">
            {answerStatus === 'correct' ? (
              <CheckCircle className="w-5 h-5 text-green-400" />
            ) : (
              <XCircle className="w-5 h-5 text-red-400" />
            )}
            <span className={`text-sm font-medium ${
              answerStatus === 'correct' ? 'text-green-400' : 'text-red-400'
            }`}>
              {answerStatus === 'correct' ? 'Correct' : 'Incorrect'}
            </span>
          </div>
        )}
      </div>

      <div className="mb-4">
        <h3 className="text-lg font-medium text-white mb-3">
          Question {question.id}:
        </h3>
        <p className="text-gray-200 whitespace-pre-line">{question.question}</p>
      </div>

      <QuestionDisplay
        question={question}
        userAnswer={userAnswer}
        showSolution={showSolution}
        onAnswerSelect={onAnswerSelect}
        onNumericalAnswer={onNumericalAnswer}
        onMatrixMatch={onMatrixMatch}
        isCorrectAnswer={isCorrectAnswer}
        getAnswerStatus={getAnswerStatus}
      />
    </motion.div>
  );
};

export default QuestionCard;
