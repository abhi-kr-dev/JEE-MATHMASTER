
import React from 'react';
import { motion } from 'framer-motion';
import { Check, X, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';

const PremiumPlans = ({ onUpgrade, isProcessing }) => {
  return (
    <div className="grid lg:grid-cols-2 gap-8 mb-12">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-effect p-8 rounded-xl"
      >
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-white mb-2">Free Plan</h2>
          <div className="text-4xl font-bold text-gray-400 mb-4">₹0</div>
          <p className="text-gray-400">Basic access to get started</p>
        </div>

        <ul className="space-y-4">
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-gray-300">100 practice questions</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-gray-300">2 mock tests per month</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-gray-300">Basic analytics</span>
          </li>
          <li className="flex items-center space-x-3">
            <X className="w-5 h-5 text-red-400" />
            <span className="text-gray-400">No PDF downloads</span>
          </li>
          <li className="flex items-center space-x-3">
            <X className="w-5 h-5 text-red-400" />
            <span className="text-gray-400">Limited previous year papers</span>
          </li>
        </ul>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
        className="glass-effect p-8 rounded-xl border-2 border-yellow-400 relative"
      >
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black px-4 py-2 rounded-full text-sm font-bold">
            RECOMMENDED
          </span>
        </div>

        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-white mb-2">Premium Plan</h2>
          <div className="text-4xl font-bold gradient-text mb-4">₹199</div>
          <p className="text-gray-300">Complete JEE preparation toolkit</p>
        </div>

        <ul className="space-y-4 mb-8">
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">15,000+ practice questions</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">Unlimited mock tests</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">Advanced analytics & insights</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">Unlimited PDF downloads</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">Complete previous year papers</span>
          </li>
          <li className="flex items-center space-x-3">
            <Check className="w-5 h-5 text-green-400" />
            <span className="text-white">Priority support</span>
          </li>
        </ul>

        <Button 
          onClick={onUpgrade} 
          disabled={isProcessing}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
          size="lg"
        >
          <CreditCard className="w-5 h-5 mr-2" />
          {isProcessing ? 'Processing...' : 'Upgrade with Stripe'}
        </Button>
        
        <p className="text-center text-xs text-gray-400 mt-3">
          Secure payment powered by Stripe
        </p>
      </motion.div>
    </div>
  );
};

export default PremiumPlans;
