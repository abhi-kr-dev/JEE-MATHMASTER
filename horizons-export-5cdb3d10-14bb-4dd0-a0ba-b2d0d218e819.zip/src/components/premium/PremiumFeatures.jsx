
import React from 'react';
import { Check, X } from 'lucide-react';

const PremiumFeatures = () => {
  const features = [
    {
      feature: 'Question Bank Access',
      free: 'Limited (100 questions)',
      premium: 'Unlimited (15,000+ questions)',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'PDF Downloads',
      free: 'Not Available',
      premium: 'Unlimited Downloads',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Mock Tests',
      free: '2 per month',
      premium: 'Unlimited',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Detailed Analytics',
      free: 'Basic stats only',
      premium: 'Advanced insights',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Previous Year Papers',
      free: 'Last 2 years only',
      premium: 'Complete archive (10+ years)',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Formula Sheets',
      free: 'Basic formulas',
      premium: 'Complete collection',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Progress Tracking',
      free: 'Basic tracking',
      premium: 'Advanced chapter-wise tracking',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Leaderboard',
      free: 'View only',
      premium: 'Full participation + badges',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Study Streak Rewards',
      free: 'Not Available',
      premium: 'Exclusive rewards & badges',
      freeIcon: X,
      premiumIcon: Check
    },
    {
      feature: 'Priority Support',
      free: 'Community support',
      premium: '24/7 priority support',
      freeIcon: X,
      premiumIcon: Check
    }
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/20">
            <th className="text-left text-white py-4 px-4">Feature</th>
            <th className="text-center text-gray-400 py-4 px-4">Free</th>
            <th className="text-center text-yellow-400 py-4 px-4">Premium</th>
          </tr>
        </thead>
        <tbody>
          {features.map((feature, index) => (
            <tr key={index} className="border-b border-white/10">
              <td className="text-white py-4 px-4 font-medium">{feature.feature}</td>
              <td className="text-center py-4 px-4">
                <div className="flex items-center justify-center space-x-2">
                  <feature.freeIcon className="w-4 h-4 text-red-400" />
                  <span className="text-gray-400 text-sm">{feature.free}</span>
                </div>
              </td>
              <td className="text-center py-4 px-4">
                <div className="flex items-center justify-center space-x-2">
                  <feature.premiumIcon className="w-4 h-4 text-green-400" />
                  <span className="text-white text-sm">{feature.premium}</span>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PremiumFeatures;
