import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('jeePrepUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error);
      localStorage.removeItem('jeePrepUser');
    }
  }, []);

  const login = async (email, password) => {
    const userData = {
      name: 'Demo User',
      email: email,
      joinedDate: new Date().toISOString(),
      isPremium: false,
    };
    localStorage.setItem('jeePrepUser', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const register = async (name, email, password) => {
    const userData = {
      name: name,
      email: email,
      joinedDate: new Date().toISOString(),
      isPremium: false,
    };
    localStorage.setItem('jeePrepUser', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const upgradeToPremium = () => {
    if (user) {
      const updatedUser = { ...user, isPremium: true };
      localStorage.setItem('jeePrepUser', JSON.stringify(updatedUser));
      setUser(updatedUser);
    }
  };

  const logout = () => {
    localStorage.removeItem('jeePrepUser');
    setUser(null);
  };

  const value = {
    user,
    login,
    logout,
    register,
    upgradeToPremium,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};