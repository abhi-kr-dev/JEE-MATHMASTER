
import { useState, useEffect } from 'react';

export const useQuestionLogic = (questions) => {
  const [answeredQuestions, setAnsweredQuestions] = useState({});
  const [showSolutions, setShowSolutions] = useState({});

  const handleAnswerSelect = (questionId, answerIndex, isMultiple = false) => {
    const question = questions.find(q => q.id === questionId);
    if (!question) return;

    let selectedAnswers;
    if (isMultiple) {
      const current = answeredQuestions[questionId] || [];
      if (current.includes(answerIndex)) {
        selectedAnswers = current.filter(i => i !== answerIndex);
      } else {
        selectedAnswers = [...current, answerIndex];
      }
    } else {
      selectedAnswers = [answerIndex];
    }

    setAnsweredQuestions(prev => ({
      ...prev,
      [questionId]: selectedAnswers
    }));

    setTimeout(() => {
      setShowSolutions(prev => ({
        ...prev,
        [questionId]: true
      }));
    }, 500);
  };

  const handleNumericalAnswer = (questionId, value) => {
    const question = questions.find(q => q.id === questionId);
    if (!question) return;

    setAnsweredQuestions(prev => ({
      ...prev,
      [questionId]: parseFloat(value)
    }));

    setTimeout(() => {
      setShowSolutions(prev => ({
        ...prev,
        [questionId]: true
      }));
    }, 500);
  };

  const handleMatrixMatch = (questionId, aIndex, bIndex) => {
    const current = answeredQuestions[questionId] || [];
    const existingMatch = current.find(match => match[0] === aIndex);
    
    let newMatches;
    if (existingMatch) {
      newMatches = current.map(match => 
        match[0] === aIndex ? [aIndex, bIndex] : match
      );
    } else {
      newMatches = [...current, [aIndex, bIndex]];
    }

    setAnsweredQuestions(prev => ({
      ...prev,
      [questionId]: newMatches
    }));
  };

  const isCorrectAnswer = (question, userAnswer) => {
    if (question.type === 'numerical') {
      return Math.abs(userAnswer - question.answer) < 0.01;
    } else if (question.type === 'matrix-match') {
      if (!userAnswer || userAnswer.length !== question.correctMatches.length) return false;
      return question.correctMatches.every(correctMatch => 
        userAnswer.some(userMatch => 
          userMatch[0] === correctMatch[0] && userMatch[1] === correctMatch[1]
        )
      );
    } else if (question.type === 'multiple-correct') {
      if (!userAnswer || userAnswer.length !== question.correctAnswer.length) return false;
      return question.correctAnswer.every(correct => userAnswer.includes(correct));
    } else {
      return userAnswer && userAnswer.length === 1 && userAnswer[0] === question.correctAnswer[0];
    }
  };

  const getAnswerStatus = (question, userAnswer) => {
    if (!userAnswer && userAnswer !== 0) return null;
    return isCorrectAnswer(question, userAnswer) ? 'correct' : 'incorrect';
  };

  return {
    answeredQuestions,
    showSolutions,
    handleAnswerSelect,
    handleNumericalAnswer,
    handleMatrixMatch,
    isCorrectAnswer,
    getAnswerStatus
  };
};
