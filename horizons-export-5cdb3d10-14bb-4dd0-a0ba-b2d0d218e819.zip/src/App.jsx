import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/AuthenticationContext.jsx';
import { ThemeProvider } from '@/contexts/ThemeContext.jsx';
import Header from '@/components/Header';
import HomePage from '@/pages/HomePage';
import QuestionsPage from '@/pages/QuestionsPage';
import QuizPage from '@/pages/quiz/QuizPage';
import MockTestPage from '@/pages/MockTestPage';
import FormulaSheetPage from '@/pages/FormulaSheetPage';
import AnalyticsPage from '@/pages/AnalyticsPage';
import PreviousPapersPage from '@/pages/PreviousPapersPage';
import ProgressPage from '@/pages/ProgressPage';
import LeaderboardPage from '@/pages/LeaderboardPage';
import PremiumPage from '@/pages/PremiumPage';
import AdminPage from '@/pages/admin/AdminPage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import ProfilePage from '@/pages/ProfilePage';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <div className="min-h-screen transition-colors duration-300">
            <Helmet>
              <title>MathSparsh - Your Ultimate JEE Main & Advanced Mathematics Platform</title>
              <meta name="description" content="Master JEE Main and Advanced mathematics with MathSparsh - comprehensive question bank, interactive quizzes, mock tests, formula sheets, and performance analytics." />
            </Helmet>
            
            <Header />
            
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/questions" element={<QuestionsPage />} />
              <Route path="/quiz" element={<QuizPage />} />
              <Route path="/mock-test" element={<MockTestPage />} />
              <Route path="/formulas" element={<FormulaSheetPage />} />
              <Route path="/analytics" element={<AnalyticsPage />} />
              <Route path="/previous-papers" element={<PreviousPapersPage />} />
              <Route path="/progress" element={<ProgressPage />} />
              <Route path="/leaderboard" element={<LeaderboardPage />} />
              <Route path="/premium" element={<PremiumPage />} />
              <Route path="/admin" element={<AdminPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/profile" element={<ProfilePage />} />
            </Routes>
            
            <Toaster />
          </div>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;